$containerName = "my-python-app"
$imageName = "youngpyo103/my-python-app:latest"
$port = 8888
$logFile = "$PSScriptRoot\deploy.log"

# 로그에 어떤 이미지 쓰는지 확인
"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 배포 시작" | Out-File -Append $logFile
"사용할 이미지: $imageName" | Out-File -Append $logFile

# 이미지 Pull
docker pull $imageName | Out-File -Append $logFile

# 기존 컨테이너 중지 및 삭제
docker stop $containerName 2>$null | Out-File -Append $logFile
docker rm $containerName 2>$null | Out-File -Append $logFile

# 새 컨테이너 실행
docker run -d --name $containerName -p $port:80 $imageName | Out-File -Append $logFile

# 완료 로그
"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 배포 완료`n" | Out-File -Append $logFile
