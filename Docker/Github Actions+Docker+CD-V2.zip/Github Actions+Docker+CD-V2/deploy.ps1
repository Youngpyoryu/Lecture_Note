$containerName = "my-python-app"
$imageName = "youngpyo103/my-python-app:latest"
$port = 8888
$logFile = "$PSScriptRoot\deploy.log"

"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 배포 시작" | Out-File -Append $logFile

docker pull $imageName | Out-File -Append $logFile
docker stop $containerName 2>$null | Out-File -Append $logFile
docker rm $containerName 2>$null | Out-File -Append $logFile
docker run -d --name $containerName -p $port:80 $imageName | Out-File -Append $logFile

"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 배포 완료`n" | Out-File -Append $logFile

