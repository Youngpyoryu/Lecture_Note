$containerName = "my-python-app"
$imageName = "youngpyo103/my-python-app:latest"
$port = 8080
$logFile = "$PSScriptRoot\deploy.log"

"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 배포 시작" | Out-File -Append $logFile
"사용할 이미지: $imageName" | Out-File -Append $logFile

# 이전 컨테이너 중지/삭제
docker stop $containerName 2>$null | Out-File -Append $logFile
docker rm $containerName 2>$null | Out-File -Append $logFile

# 이전 이미지도 삭제해 강제 새 이미지 사용
docker rmi $imageName 2>$null | Out-File -Append $logFile

# 컨테이너 실행 (이름 지정)
docker run -d --name $containerName -p $port:80 $imageName | Out-File -Append $logFile

"[$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')] 배포 완료`n" | Out-File -Append $logFile
