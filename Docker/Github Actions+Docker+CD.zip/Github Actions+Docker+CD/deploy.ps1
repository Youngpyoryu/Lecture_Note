# deploy.ps1
$containerName = "my-python-app"
$imageName = "youngpyo103/my-python-app:latest"

Write-Host "🔄 DockerHub에서 최신 이미지 pull 중..."
docker pull $imageName

Write-Host "🛑 기존 컨테이너 중지/삭제 중..."
docker stop $containerName 2>$null
docker rm $containerName 2>$null

Write-Host "🚀 새 컨테이너 실행 중..."
docker run -d --name $containerName -p 80:80 $imageName

Write-Host "✅ 배포 완료!"
