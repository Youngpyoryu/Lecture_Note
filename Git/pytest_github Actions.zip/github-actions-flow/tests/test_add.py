import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))) #상위 폴더 접근

from main import add

def test_add():
    assert add(2, 3) == 5

