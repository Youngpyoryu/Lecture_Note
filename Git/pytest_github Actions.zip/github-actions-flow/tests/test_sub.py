import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))) #상위 폴더 접근

from main import sub

def test_sub():
    assert sub(5, 3) == 2
