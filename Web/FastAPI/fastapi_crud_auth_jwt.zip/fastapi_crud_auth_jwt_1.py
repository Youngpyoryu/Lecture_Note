from fastapi import FastAPI, HTTPException, Depends, Query
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from sqlalchemy import Column, Integer, String, Boolean, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
from typing import Optional
from fastapi import Request
import os

# 설정
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_URL = f"sqlite:///{os.path.join(BASE_DIR, 'todos.db')}"
SECRET_KEY = "your-secret-key"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# DB 설정
engine = create_engine(DB_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(bind=engine, autocommit=False, autoflush=False)
Base = declarative_base()

# 암호화 & 인증 토큰 설정
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
# oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/login", auto_error=True) #토큰을 입력하지 않아도 됨.

from fastapi.security import APIKeyHeader

api_key_header = APIKeyHeader(name="Authorization", auto_error=False) #토큰 인증

def hash_password(password: str):
    return pwd_context.hash(password)

def verify_password(plain: str, hashed: str):
    return pwd_context.verify(plain, hashed)

def create_access_token(data: dict, expires_delta: timedelta = None):
    to_encode = data.copy()
    expire = datetime.utcnow() + (expires_delta or timedelta(minutes=15))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# 인증 사용자 확인 + 쿼리 파라미터 (선택)

def get_current_user(
    request: Request,
    token: str = Depends(api_key_header),  # 자동 토큰 인증 : oauth2_scheme
    db: Session = Depends(get_db),
):
    if not token:
        raise HTTPException(status_code=401, detail="Access token is missing")

    print(f"[DEBUG] token: {token}")
    local_kw = request.query_params.get("local_kw", None)
    print(f"[공통 local_kw]: {local_kw}")

    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    return user

# 모델 정의
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, nullable=False)
    password = Column(String, nullable=False)

class Todo(Base):
    __tablename__ = "todos"
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    completed = Column(Boolean, default=False)
    owner_id = Column(Integer, nullable=False)

class UserCreate(BaseModel):
    username: str
    password: str

class Token(BaseModel):
    access_token: str
    token_type: str

class TodoCreate(BaseModel):
    title: str
    completed: bool = False

# FastAPI 앱 생성
app = FastAPI()
Base.metadata.create_all(bind=engine)

# 라우팅
@app.post("/register")
def register(
    request: Request,
    user: UserCreate,
    db: Session = Depends(get_db)
):
    local_kw = request.query_params.get("local_kw")
    if db.query(User).filter(User.username == user.username).first():
        raise HTTPException(status_code=400, detail="이미 존재하는 사용자입니다.")
    hashed_pw = hash_password(user.password)
    db.add(User(username=user.username, password=hashed_pw))
    db.commit()
    return {"message": "회원가입 완료"}

@app.post("/login", response_model=Token)
def login(
    request: Request,
    form_data: OAuth2PasswordRequestForm = Depends(),
    db: Session = Depends(get_db)

):
    local_kw = request.query_params.get("local_kw")
    print(f"[LOGIN] local_kw: {local_kw}")
    db_user = db.query(User).filter(User.username == form_data.username).first()
    if not db_user or not verify_password(form_data.password, db_user.password):
        raise HTTPException(status_code=401, detail="로그인 실패")
    access_token = create_access_token(
        data={"sub": db_user.username},
        expires_delta=timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    return {"access_token": access_token, "token_type": "bearer"}

@app.post("/todos")
def create_todo(
    todo: TodoCreate,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    new_todo = Todo(title=todo.title, completed=todo.completed, owner_id=current_user.id)
    db.add(new_todo)
    db.commit()
    db.refresh(new_todo)
    return new_todo

@app.get("/todos")
def read_todos(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return db.query(Todo).filter(Todo.owner_id == current_user.id).all()

@app.delete("/todos/{todo_id}")
def delete_todo(
    todo_id: int,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    todo = db.query(Todo).filter(Todo.id == todo_id, Todo.owner_id == current_user.id).first()
    if not todo:
        raise HTTPException(status_code=404, detail="할 일을 찾을 수 없음")
    db.delete(todo)
    db.commit()
    return {"message": "삭제 완료"}



#------------------------------------------HTML 랜더링-----------------------------------------
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from fastapi.responses import RedirectResponse
from fastapi import Form

# 템플릿과 정적 파일 폴더 등록
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
def home(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/register-form", response_class=HTMLResponse)
def register_form(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.get("/todos-page", response_class=HTMLResponse)
def todos_page(request: Request):
    return templates.TemplateResponse("todos.html", {"request": request})

@app.post("/web/create_todo")
def web_create_todo(
    request: Request,
    title: str = Depends(lambda req: req.form()["title"]),
    token: str = Depends(lambda req: req.form()["token"]),
    db: Session = Depends(get_db),
):
    # JWT 토큰 검증
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    todo = Todo(title=title, owner_id=user.id)
    db.add(todo)
    db.commit()

    # 리디렉션 (토큰 다시 포함)
    return RedirectResponse(url=f"/web/todos?token={token}", status_code=303)


@app.post("/web/delete_todo/{todo_id}")
def web_delete_todo(
    request: Request,
    todo_id: int,
    token: str = Depends(lambda req: req.form()["token"]),
    db: Session = Depends(get_db),
):
    # JWT 토큰 검증
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    todo = db.query(Todo).filter(Todo.id == todo_id, Todo.owner_id == user.id).first()
    if not todo:
        raise HTTPException(status_code=404, detail="Todo not found")

    db.delete(todo)
    db.commit()

    return RedirectResponse(url=f"/web/todos?token={token}", status_code=303)


@app.get("/web/todos")
def web_show_todos(
    request: Request,
    token: str = Query(...),
    db: Session = Depends(get_db),
):
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username = payload.get("sub")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")

    user = db.query(User).filter(User.username == username).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")

    todos = db.query(Todo).filter(Todo.owner_id == user.id).all()
    return templates.TemplateResponse("todos.html", {
        "request": request,
        "todos": todos,
        "token": token
    })

@app.get("/web/login")
def show_login_form(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})


@app.post("/web/login")
def process_login(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    user = db.query(User).filter(User.username == username).first()
    if not user or not verify_password(password, user.password):
        return templates.TemplateResponse("login.html", {
            "request": request,
            "error": "로그인 실패. 아이디 또는 비밀번호 확인"
        })
    
    access_token = create_access_token(data={"sub": user.username})
    return RedirectResponse(url=f"/web/todos?token={access_token}", status_code=303)

# 회원가입 폼 보여주기
@app.get("/web/register")
def show_register_form(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

# 회원가입 처리
@app.post("/web/register")
def web_register(
    request: Request,
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db)
):
    if db.query(User).filter(User.username == username).first():
        return templates.TemplateResponse("register.html", {
            "request": request,
            "error": "이미 존재하는 사용자입니다."
        })

    hashed_pw = hash_password(password)
    db.add(User(username=username, password=hashed_pw))
    db.commit()
    return RedirectResponse(url="/web/login", status_code=303)
