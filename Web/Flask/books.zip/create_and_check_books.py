import sqlite3

# 데이터베이스 연결
db = sqlite3.connect("books-collection.db")
cursor = db.cursor()

# 테이블이 없으면 생성
cursor.execute("""
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY,
    title VARCHAR(250) NOT NULL UNIQUE,
    author VARCHAR(250) NOT NULL,
    rating FLOAT NOT NULL
)
""")
db.commit()

# 테이블 목록 확인
cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
tables = cursor.fetchall()
print("테이블 목록:", tables)

# 'books' 테이블 확인 및 데이터 삽입/조회
if ('books',) in tables:
    cursor.execute("SELECT * FROM books")
    rows = cursor.fetchall()

    if rows:
        print("books 테이블 내용:")
        for row in rows:
            print(row)
    else:
        print(" books 테이블이 있지만 데이터가 없습니다.")
        print(" 더미 데이터 삽입 중...")

        # 더미 데이터 삽입
        dummy_books = [
            ("The Alchemist", "Paulo Coelho", 4.7),
            ("Clean Code", "Robert C. Martin", 4.9),
            ("Fluent Python", "Luciano Ramalho", 4.8)
        ]
        cursor.executemany("INSERT INTO books (title, author, rating) VALUES (?, ?, ?)", dummy_books)
        db.commit()
        print("삽입 완료. 다음 실행 시 확인 가능.")
else:
    print("❗ 'books' 테이블이 존재하지 않습니다.")

db.close()
