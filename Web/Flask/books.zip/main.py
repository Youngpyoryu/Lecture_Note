from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# 1. DB 연결 설정
engine = create_engine('sqlite:///example.db', echo=True)
#데이터베이스 연결 객체 / ex) SQLite 파일에 연결

# 2. ORM 모델의 기반 클래스 생성
Base = declarative_base()
#모든 테이블 클래스의 부모 역할

# 3. 테이블 모델 정의
# python 클래스와 SQL 테이블은 유사하다.
class User(Base):
    __tablename__ = 'users'  # 테이블명
    
    id = Column(Integer, primary_key=True) # column
    name = Column(String) # column
    age = Column(Integer) # column

# 4. 테이블 실제 생성
Base.metadata.create_all(engine)


# 5. Session 생성
Session = sessionmaker(bind=engine)
session = Session()
# 데이터베이스와의 실제 대화창 / CRUD을 통해 작업함.

# 6. 데이터 추가
new_user = User(name="Alice", age=25)
session.add(new_user)
session.commit()

# 7. 데이터 조회
users = session.query(User).all()
for user in users:
    print(user.name, user.age)

# 8. 세션 종료
session.close()
