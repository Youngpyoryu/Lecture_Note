import sqlite3

db = sqlite3.connect("books-collection.db")
cursor = db.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS books (
    id INTEGER PRIMARY KEY,
    title VARCHAR(250) NOT NULL UNIQUE,
    author VARCHAR(250) NOT NULL,
    rating FLOAT NOT NULL
)
""")

db.commit()
db.close()
