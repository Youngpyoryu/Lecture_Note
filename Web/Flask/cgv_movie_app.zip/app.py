#app.py
from flask import Flask, render_template
from models import db, Movie

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:1234@localhost:3306/cgv_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

@app.route('/')
def home():
    movies = Movie.query.all()
    return render_template('home.html', movies=movies)

@app.route('/movie/<int:movie_id>')
def detail(movie_id):
    movie = Movie.query.get(movie_id)
    if movie:
        return render_template('detail.html', movie=movie)
    else:
        return "<h1>영화를 찾을 수 없습니다.</h1>", 404

if __name__ == '__main__':
    app.run(debug=True)
