#crawler.py
import requests
from bs4 import BeautifulSoup
import pandas as pd
import matplotlib.pyplot as plt
import ssl
import urllib3

#  CGV 서버는 구형 SSL 설정(DH 키 사이즈가 작음)을 사용함
# → Python 3.13 이상에서는 보안 수준이 강화되어 SSL 연결이 거부됨
# → 이를 해결하기 위해 SSL 보안 수준을 완화함 (SECLEVEL=1)
urllib3.disable_warnings()

#  보안 수준 낮은 SSL 연결 허용 설정
ctx = ssl.create_default_context()
ctx.check_hostname = False  # 호스트 이름 검증 비활성화
ctx.set_ciphers('DEFAULT:@SECLEVEL=1')


# 커스텀 어댑터 생성: requests가 위의 SSL context를 사용하도록 강제
class CustomAdapter(requests.adapters.HTTPAdapter):
    def init_poolmanager(self, *args, **kwargs):
        kwargs['ssl_context'] = ctx
        return super().init_poolmanager(*args, **kwargs)

# 세션 객체 생성 후 HTTPS 요청에 커스텀 어댑터 장착
session = requests.Session()
session.mount('https://', CustomAdapter())

class CGVMovieCrawler:
    def __init__(self):
        self.url = 'https://www.cgv.co.kr/movies/'
        self.movies = []

    def fetch(self):
        try:
            res = session.get(self.url, headers={
                "User-Agent": "Mozilla/5.0"
            }, verify=False)

            if res.status_code != 200:
                print(f" 요청 실패: {res.status_code}")
                return None

            return BeautifulSoup(res.text, 'html.parser')
        except Exception as e:
            print(f" fetch 에러: {e}")
            return None

    def parse(self, soup):
        movie_items = soup.select('div.sect-movie-chart ol li')
        print(f"[디버그] 수집된 영화 수: {len(movie_items)}")

        for item in movie_items:
            title_tag = item.select_one('strong.title')
            percent_tag = item.select_one('strong.percent span')
            open_date_tag = item.select_one('span.txt-info')
            poster_tag = item.select_one('span.thumb-image img')

            title = title_tag.text.strip() if title_tag else "제목 없음"
            percent = float(percent_tag.text.strip().replace('%', '')) if percent_tag else 0.0
            open_date = open_date_tag.text.strip().replace('개봉', '').strip() if open_date_tag else "정보 없음"
            poster = poster_tag['src'] if poster_tag and poster_tag.has_attr('src') else "이미지 없음"

            self.movies.append({
                'Title': title,
                'Reservation': percent,
                'OpenDate': open_date,
                'PosterURL': poster
            })


    def save_to_csv(self, filename='movies.csv'):
        if not self.movies:
            print(" 저장할 데이터가 없습니다.")
            return
        df = pd.DataFrame(self.movies)
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        print(f" {filename} 저장 완료!")
        return df

    def analyze(self, df):
        import os
        from matplotlib import rc

        # 📁 디렉토리 생성
        os.makedirs('static/img', exist_ok=True)

        #  한글 폰트 설정 (Windows 기준)
        rc('font', family='Malgun Gothic')
        plt.rcParams['axes.unicode_minus'] = False

        print("\n [분석 결과 요약]")
        print("- 평균 예매율:", round(df['Reservation'].mean(), 2), "%")
        print("- TOP 5 예매율 영화:")
        print(df.nlargest(5, 'Reservation')[['Title', 'Reservation']])

        # 시각화 저장
        plt.figure(figsize=(10, 6))
        top5 = df.nlargest(5, 'Reservation')
        plt.bar(top5['Title'], top5['Reservation'], color='skyblue')
        plt.xticks(rotation=30)
        plt.title('예매율 TOP 5 영화')
        plt.ylabel('예매율 (%)')
        plt.tight_layout()
        plt.savefig('static/img/reservation_top5.png')
        print(" 예매율 TOP5 그래프 → static/img/reservation_top5.png 저장됨")

    def run(self):
        soup = self.fetch()
        if soup:
            self.parse(soup)
            df = self.save_to_csv()
            if df is not None:
                self.analyze(df)

if __name__ == '__main__':
    crawler = CGVMovieCrawler()
    crawler.run()
