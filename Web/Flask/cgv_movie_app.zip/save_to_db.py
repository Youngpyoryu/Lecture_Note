import pandas as pd
from flask import Flask
from models import db, Movie  # SQLAlchemy 객체와 모델 import

# 🛠 Flask 앱 생성 및 MySQL 설정
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:1234@localhost:3306/cgv_db'  #  자신의 계정/비밀번호에 맞게 수정
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

#  SQLAlchemy에 앱 등록
db.init_app(app)

#  데이터 적재 로직 (Flask 앱 context 안에서 실행)
with app.app_context():
    # 기존 테이블을 모두 삭제 후 재생성 (안전하게 초기화)
    db.drop_all()
    db.create_all()

    # movies.csv 읽기
    df = pd.read_csv('movies.csv')

    # 한 행씩 Movie 객체로 변환하여 DB에 추가
    for _, row in df.iterrows():
        movie = Movie(
            title=row['Title'],               # 열 이름은 CSV와 정확히 일치해야 함
            reservation=row['Reservation'],
            open_date=row['OpenDate'],
            poster_url=row['PosterURL']
        )
        db.session.add(movie)

    # 모든 변경사항 커밋
    db.session.commit()

    print(" movies.csv → MySQL DB 저장 완료")
