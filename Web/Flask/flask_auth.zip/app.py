#app.py
from flask import Flask, render_template, request, redirect, url_for, session, flash
from models import db, User
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'secret-key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

# 첫 실행 시 테이블 생성
with app.app_context():
    db.create_all()

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        pw = generate_password_hash(request.form['password'])
        if User.query.filter_by(username=username).first():
            flash("이미 존재하는 사용자입니다.")
            return redirect(url_for('register'))

        new_user = User(username=username, password=pw)
        db.session.add(new_user)
        db.session.commit()
        flash("회원가입 완료!")
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        pw = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password, pw):
            session['user_id'] = user.id
            flash("로그인 성공")
            return redirect(url_for('home'))
        flash("로그인 실패")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    flash("로그아웃 완료")
    return redirect(url_for('home'))

@app.route('/mypage')
def mypage():
    if 'user_id' not in session:
        flash("로그인 후 이용 가능합니다.")
        return redirect(url_for('login'))

    user = User.query.get(session['user_id'])
    return render_template('mypage.html', user=user)


if __name__ == '__main__':
    app.run(debug=True)
