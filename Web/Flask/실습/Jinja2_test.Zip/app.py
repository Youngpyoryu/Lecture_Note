from flask import Flask, render_template
app = Flask(__name__)

@app.get("/")
def index():
    todo_list = ["A", "B", "C"]
    return render_template("index.html", todo_list=todo_list)

if __name__ == "__main__":
    app.run(debug=True)
