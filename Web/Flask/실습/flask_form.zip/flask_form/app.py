from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/form', methods=['GET', 'POST'])
def form():
    if request.method == 'POST':
        username = request.form.get('username')
        return render_template(
            'result.html',
            message=f'입력한 사용자 이름은: {username}'
        )
    return render_template('form.html')

if __name__ == '__main__':
    app.run(debug=True)
