from flask import Flask, request, redirect, render_template
import sqlite3

app = Flask(__name__)
DB = "users.db"


def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            )
            """
        )


@app.route("/")
def index():
    with get_db() as conn:
        users = conn.execute("SELECT id, name FROM users").fetchall()
    return render_template("users.html", users=users)


@app.route("/create", methods=["POST"])
def create():
    name = request.form.get("name")
    if name:
        with get_db() as conn:
            conn.execute("INSERT INTO users (name) VALUES (?)", (name,))
    return redirect("/")


@app.route("/update/<int:user_id>", methods=["POST"])
def update(user_id):
    new_name = request.form.get("name")
    if new_name:
        with get_db() as conn:
            conn.execute(
                "UPDATE users SET name=? WHERE id=?",
                (new_name, user_id),
            )
    return redirect("/")


@app.route("/delete/<int:user_id>", methods=["POST"])
def delete(user_id):
    with get_db() as conn:
        conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    return redirect("/")


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
