def sum(a, b):
    return a + b
def multiply(a, b):
    return a * b


if __name__ == "__main__":
    print("Sum of 3 and 5 is:", sum(3, 5))
    print("Product of 3 and 5 is:", multiply(3, 5))