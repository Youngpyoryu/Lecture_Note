from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import List, Optional

from flask import Flask, render_template, request, redirect, url_for


# -------------------------
# App & Storage Settings
# -------------------------
app = Flask(__name__)

DATA_PATH = Path("todos.json")  # 서버 재시작 후에도 유지하고 싶으면 이 파일을 사용


# -------------------------
# Model
# -------------------------
@dataclass
class Todo:
    id: int
    text: str
    done: bool = False


# -------------------------
# Persistence (JSON)
# -------------------------
def load_todos() -> List[Todo]:
    """Load todos from JSON file. If missing or invalid, return empty list."""
    if not DATA_PATH.exists():
        return []

    try:
        raw = json.loads(DATA_PATH.read_text(encoding="utf-8"))
        return [Todo(**item) for item in raw]
    except Exception:
        # 실습용: 파일이 깨져도 앱이 죽지 않게 빈 리스트로 복구
        return []


def save_todos(todos: List[Todo]) -> None:
    """Save todos to JSON file."""
    raw = [asdict(t) for t in todos]
    DATA_PATH.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")


# 메모리 상태 + 파일 동기화
TODOS: List[Todo] = load_todos()


def next_id(todos: List[Todo]) -> int:
    """Generate next id based on current max id."""
    if not todos:
        return 1
    return max(t.id for t in todos) + 1


def find_todo(todos: List[Todo], tid: int) -> Optional[Todo]:
    """Find a todo by id."""
    return next((t for t in todos if t.id == tid), None)


# -------------------------
# Routes
# -------------------------
@app.get("/")
def home():
    # 템플릿에서 바로 출력할 수 있게 단순한 값만 전달
    return render_template("todos.html", todos=TODOS, error=None)


@app.post("/todos/add")
def add_todo():
    text = request.form.get("text", "").strip()

    # 1) 유효성 검사(빈 입력 막기)
    if not text:
        return render_template("todos.html", todos=TODOS, error="할 일을 입력하세요.")

    # 2) 추가
    TODOS.append(Todo(id=next_id(TODOS), text=text, done=False))
    save_todos(TODOS)

    # 3) PRG: POST 후 redirect (새로고침 중복 제출 방지)
    return redirect(url_for("home"))


@app.post("/todos/toggle/<int:tid>")
def toggle_todo(tid: int):
    todo = find_todo(TODOS, tid)
    if todo:
        todo.done = not todo.done
        save_todos(TODOS)
    return redirect(url_for("home"))


@app.post("/todos/delete/<int:tid>")
def delete_todo(tid: int):
    global TODOS
    TODOS = [t for t in TODOS if t.id != tid]
    save_todos(TODOS)
    return redirect(url_for("home"))


@app.post("/todos/clear")
def clear_all():
    """전체 삭제(데모용)."""
    TODOS.clear()
    save_todos(TODOS)
    return redirect(url_for("home"))


if __name__ == "__main__":
    app.run(debug=True)
