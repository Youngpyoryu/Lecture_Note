# 실습: 실제 웹사이트 크롤링 (robots 준수)

이 실습의 목표는:
- robots.txt를 먼저 확인하고
- Playwright는 구조 탐색에만 사용하며
- 실제 데이터 수집은 HTTP 기반 스크립트로 수행하는 것이다.

Playwright는 크롤러가 아니라 탐색기다.
수집은 requests로 한다.


이 실습에서는 Playwright와 requests를 함께 사용하여 웹사이트를 크롤링하는 방법을 배운다.