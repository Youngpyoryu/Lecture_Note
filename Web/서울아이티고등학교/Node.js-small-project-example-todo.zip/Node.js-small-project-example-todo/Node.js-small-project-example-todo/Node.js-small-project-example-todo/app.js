// Import Modules
const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");

// Create Express server
const app = express(); // Server on port 3000

// Server setting - View, Static Files, Body Parser
app.set("view engine", "ejs"); // Use ejs as a view engine
app.set("views", path.join(__dirname, 'views')); // Set the views folder path

app.use("/public", express.static(__dirname + '/public')); // Serve static files

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

// Router Setting
const router = require("./routes/index"); // Import router from routes folder
app.use(router);

// MongoDB Connection String
const mongoDB = "mongodb://127.0.0.1:27017/node"; // Local MongoDB URL (use 127.0.0.1 instead of localhost)

mongoose.connect(mongoDB, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("mongoDB Connected!"); // Successful connection message

        // Start server only after successful MongoDB connection
        app.listen(3000, () => {
            console.log("Server listening on port 3000!");
        });
    })
    .catch((err) => {
        // If connection fails, log the error
        console.error("MongoDB Connection Error:", err.message);
    });
