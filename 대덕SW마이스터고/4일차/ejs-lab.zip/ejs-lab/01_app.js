const express = require("express");
const app = express();

app.set("view engine", "ejs");
app.set("views", "views");

app.get("/", (req, res) => {
  const name = req.query.name || "Guest";
  res.render("01_hello", { title: "EJS 연습", name });
});

app.listen(3000, () => console.log("01: http://localhost:3000"));
