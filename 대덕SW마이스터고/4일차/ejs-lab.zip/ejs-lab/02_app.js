const express = require("express");
const app = express();
app.set("view engine", "ejs");
app.set("views", "views");

app.get("/", (req, res) => {
  const isLogin = req.query.login === "1";
  res.render("02_if", { isLogin });
});

app.listen(3000, () => console.log("02: http://localhost:3000"));
