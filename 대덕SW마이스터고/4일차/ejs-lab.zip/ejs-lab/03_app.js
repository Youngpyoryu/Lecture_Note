const express = require("express");
const app = express();
app.set("view engine", "ejs");
app.set("views", "views");

app.get("/", (req, res) => {
  const fruits = ["apple", "banana", "orange"];
  res.render("03_list", { fruits });
});

app.listen(3000, () => console.log("03: http://localhost:3000"));
