require("dotenv").config();
const express = require("express");
const mongoose = require("mongoose");

const app = express();

// EJS 설정
app.set("view engine", "ejs");
app.set("views", "views");

// 폼 body 파싱
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// 정적 파일(원하면 css)
app.use(express.static("public"));

// Todo 모델(07 기준: 길이 검증 포함)
const TodoSchema = new mongoose.Schema(
  {
    content: {
      type: String,
      required: [true, "내용(content)은 필수입니다."],
      trim: true,
      minlength: [1, "내용은 1자 이상이어야 합니다."],
      maxlength: [50, "내용은 50자 이하여야 합니다."],
    },
    done: { type: Boolean, default: false },
  },
  { timestamps: true }
);
const Todo = mongoose.model("Todo", TodoSchema, "todos");

// EJS 페이지: /todos?q=...
app.get("/todos", async (req, res) => {
  const q = (req.query.q || "").trim();
  const filter = q ? { content: { $regex: q, $options: "i" } } : {};
  const todos = await Todo.find(filter).sort({ createdAt: -1 });
  res.render("08_todo", { todos, q });
});

// 추가(폼 POST) -> 다시 /todos로
app.post("/todos", async (req, res) => {
  try {
    await Todo.create({ content: req.body.content });
    res.redirect("/todos");
  } catch (e) {
    const msg = e?.errors?.content?.message || "입력값이 올바르지 않습니다.";
    const q = "";
    const todos = await Todo.find().sort({ createdAt: -1 });
    res.status(400).render("08_todo", { todos, q, error: msg });
  }
});

// 삭제(폼 POST) -> 다시 /todos로
app.post("/todos/:id/delete", async (req, res) => {
  await Todo.findByIdAndDelete(req.params.id);
  res.redirect("/todos");
});

// 토글(폼 POST) -> 다시 /todos로
app.post("/todos/:id/toggle", async (req, res) => {
  const todo = await Todo.findById(req.params.id);
  if (todo) {
    todo.done = !todo.done;
    await todo.save();
  }
  res.redirect("/todos");
});

async function start() {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error("MONGODB_URI가 .env에 없습니다.");
  await mongoose.connect(uri);
  console.log("MongoDB connected");

  const PORT = process.env.PORT || 3000;
  app.listen(PORT, () => console.log(`EJS server: http://localhost:${PORT}/todos`));
}

start().catch((e) => {
  console.error("ERROR:", e.message);
  process.exit(1);
});
