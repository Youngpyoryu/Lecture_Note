<!doctype html>
<html lang="ko">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>07 - Todo (Validation)</title>
  <style>
    body { font-family: system-ui, sans-serif; max-width: 720px; margin: 40px auto; }
    .row { display: flex; gap: 8px; margin: 10px 0; }
    input[type="text"] { flex: 1; padding: 10px; }
    button { padding: 10px 14px; cursor: pointer; }
    ul { padding-left: 18px; }
    li { margin: 10px 0; }
    .meta { color: #666; font-size: 12px; margin-left: 6px; }
    .hint { color: #444; font-size: 13px; margin-top: 8px; }

    .error {
      display: none;
      margin: 12px 0;
      padding: 10px 12px;
      border: 1px solid #ff6b6b;
      background: #fff5f5;
      color: #c92a2a;
      border-radius: 8px;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <h1>07. Todo (검증 + 에러 표시)</h1>

  <form id="form" class="row">
    <input id="content" type="text" placeholder="할 일을 입력하세요 (1~50자)" autocomplete="off" />
    <button type="submit">추가</button>
  </form>

  <div id="errorBox" class="error"></div>

  <div class="row">
    <input id="q" type="text" placeholder="검색어(q)를 입력하세요" autocomplete="off" />
    <button id="clear" type="button">검색 초기화</button>
  </div>

  <p class="hint">내용은 1~50자만 허용됩니다. 조건을 어기면 에러가 화면에 표시됩니다.</p>

  <p class="meta" id="status"></p>

  <h3>리스트</h3>
  <ul id="list"></ul>

  <script src="./07_app.js"></script>
</body>
</html>
