const form = document.getElementById("form");
const input = document.getElementById("content");

const qInput = document.getElementById("q");
const clearBtn = document.getElementById("clear");

const list = document.getElementById("list");
const statusEl = document.getElementById("status");

const errorBox = document.getElementById("errorBox");

let currentQ = "";

function showError(msg) {
  errorBox.textContent = msg;
  errorBox.style.display = "block";
}

function clearError() {
  errorBox.textContent = "";
  errorBox.style.display = "none";
}

async function fetchTodos() {
  statusEl.textContent = "불러오는 중...";
  const url = currentQ ? `/api/todos?q=${encodeURIComponent(currentQ)}` : "/api/todos";

  const res = await fetch(url);
  const todos = await res.json();

  render(todos);
  statusEl.textContent = currentQ
    ? `검색어: "${currentQ}" | 결과 ${todos.length}개`
    : `총 ${todos.length}개`;
}

function render(todos) {
  list.innerHTML = "";
  for (const t of todos) {
    const li = document.createElement("li");

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = !!t.done;
    checkbox.addEventListener("change", async () => {
      clearError();
      const res = await fetch(`/api/todos/${t._id}/toggle`, { method: "PATCH" });
      if (!res.ok) {
        const err = await res.json();
        showError(err.message || "토글 실패");
        return;
      }
      await fetchTodos();
    });
    li.appendChild(checkbox);

    const text = document.createElement("span");
    text.textContent = " " + t.content;
    if (t.done) text.style.textDecoration = "line-through";
    li.appendChild(text);

    const meta = document.createElement("span");
    meta.className = "meta";
    meta.textContent = `(${new Date(t.createdAt).toLocaleString()})`;
    li.appendChild(meta);

    const delBtn = document.createElement("button");
    delBtn.textContent = "삭제";
    delBtn.style.marginLeft = "10px";
    delBtn.addEventListener("click", async () => {
      clearError();
      const res = await fetch(`/api/todos/${t._id}`, { method: "DELETE" });
      if (!res.ok) {
        const err = await res.json();
        showError(err.message || "삭제 실패");
        return;
      }
      await fetchTodos();
    });
    li.appendChild(delBtn);

    list.appendChild(li);
  }
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  clearError();

  const content = input.value.trim();

  if (content.length < 1) return showError("내용은 1자 이상이어야 합니다.");
  if (content.length > 50) return showError("내용은 50자 이하여야 합니다.");

  const res = await fetch("/api/todos", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ content }),
  });

  if (!res.ok) {
    const err = await res.json();
    showError(err.message || "추가 실패");
    return;
  }

  input.value = "";
  await fetchTodos();
});

qInput.addEventListener("input", async () => {
  currentQ = qInput.value.trim();
  await fetchTodos();
});

clearBtn.addEventListener("click", async () => {
  qInput.value = "";
  currentQ = "";
  await fetchTodos();
});

fetchTodos();
