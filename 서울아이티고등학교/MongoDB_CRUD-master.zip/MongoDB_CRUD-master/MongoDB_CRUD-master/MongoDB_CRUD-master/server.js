const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const MongoClient = require('mongodb').MongoClient;

// 로컬 MongoDB 연결 URL (IPv4 주소로 변경)
const url = 'mongodb://127.0.0.1:27017';  // 로컬 MongoDB 연결 URL (127.0.0.1 사용)

// 포트 설정
var port = process.env.PORT || 4000;

// MongoDB 연결 및 CRUD 핸들러 설정
MongoClient.connect(url, { useUnifiedTopology: true }, (err, database) => {
    if (err) {
        // MongoDB 연결 실패 시 오류 메시지 출력
        console.error("MongoDB 연결 실패:", err.message);
        return;
    }
    console.log("MongoDB에 성공적으로 연결됨!");  // 연결 성공 메시지

    // 데이터베이스 선택
    const db = database.db('star-wars-quotes');  // 'star-wars-quotes' 데이터베이스 선택
    const quotesCollection = db.collection('quotes');  // 'quotes' 컬렉션 선택

    // 뷰 엔진 설정
    app.set('view engine', 'ejs');

    // body-parser 설정
    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(express.static('public'));
    app.use(bodyParser.json());

    // DELETE 요청 처리 (데이터 삭제)
    app.delete('/quotes', (req, res) => {
        quotesCollection.deleteOne({ name: req.body.name })
            .then(result => {
                if (result.deletedCount === 0) {
                    return res.json('삭제할 인용문이 없습니다.');
                }
                res.json(`${req.body.name}의 인용문이 삭제되었습니다.`);
            })
            .catch(error => console.error(error));
    });

    // PUT 요청 처리 (데이터 수정)
    app.put('/quotes', (req, res) => {
        quotesCollection.findOneAndUpdate(
            { name: req.body.name },
            {
                $set: {
                    name: req.body.name,
                    quote: req.body.quote
                }
            },
            { upsert: true }
        )
        .then(result => {
            res.json('성공적으로 인용문이 수정되었습니다.');
        })
        .catch(error => console.error(error));
    });

    // POST 요청 처리 (새로운 데이터 추가)
    app.post('/quotes', (req, res) => {
        quotesCollection.insertOne(req.body)
            .then(result => {
                res.redirect('/');
            })
            .catch(error => console.error(error));
    });

    // GET 요청 처리 (홈페이지)
    app.get('/', (req, res) => {
        quotesCollection.find().toArray()
            .then(results => {
                res.render('index.ejs', { quotes: results });
            })
            .catch(error => console.error(error));
    });

    // 서버 시작
    app.listen(port, () => {
        console.log(`서버가 포트 ${port}에서 실행 중입니다.`);
    });
});
