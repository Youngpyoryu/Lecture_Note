const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const MongoClient = require('mongodb').MongoClient;

// 로컬 MongoDB 연결 URL
const url = 'mongodb://localhost:27017';

// 포트 설정
var port = process.env.PORT || 4000;

// 서버 시작
app.listen(port, function() {
    console.log('listening on 4000')
});

// CRUD 핸들러
MongoClient.connect(url, {
    useUnifiedTopology: true
}, (err, database) => {
    if (err) {
        console.error("MongoDB 연결 실패", err);
        return;
    }
    console.log("Connected to Database");

    // 데이터베이스 선택
    const db = database.db('star-wars-quotes');  // 'star-wars-quotes' 데이터베이스 선택
    const quotesCollection = db.collection('quotes');  // 'quotes' 컬렉션 선택

    // 뷰 엔진 설정
    app.set('view engine', 'ejs');
    // body-parser 설정
    app.use(bodyParser.urlencoded({ extended: true }));
    app.use(express.static('public'));
    app.use(bodyParser.json());

    // DELETE 요청 처리 (데이터 삭제)
    app.delete('/quotes', (req, res) => {
        quotesCollection.deleteOne({ name: req.body.name })
            .then(result => {
                if (result.deletedCount === 0) {
                    return res.json('No quote to Delete');
                }
                res.json("Deleted BabO's quote");
            })
            .catch(error => console.error(error));
    });

    // PUT 요청 처리 (데이터 수정)
    app.put('/quotes', (req, res) => {
        quotesCollection.findOneAndUpdate(
            { name: 'SSeung' },
            {
                $set: {
                    name: req.body.name,
                    quote: req.body.quote
                }
            },
            { upsert: true }
        )
        .then(result => {
            res.json('Success');
        })
        .catch(error => console.error(error));
    });

    // POST 요청 처리 (새로운 데이터 추가)
    app.post('/quotes', (req, res) => {
        quotesCollection.insertOne(req.body)
            .then(result => {
                res.redirect('/');
            })
            .catch(error => console.error(error));
    });

    // GET 요청 처리 (홈페이지)
    app.get('/', (req, res) => {
        const cursor = db.collection('quotes').find().toArray()
            .then(results => {
                res.render('index.ejs', { quotes: results });
            })
            .catch(error => console.error(error));
    });
});
