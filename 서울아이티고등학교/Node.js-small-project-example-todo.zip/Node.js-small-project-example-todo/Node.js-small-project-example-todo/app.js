// 필요한 모듈을 가져옵니다.
const express = require("express");
const mongoose = require("mongoose");
const path = require("path");
const bodyParser = require("body-parser");

// Express 서버 객체 생성
const app = express(); // 3000번 포트에서 Todo 앱을 실행할 Express 서버 객체 생성

// 서버 설정 - 뷰 엔진, 정적 파일 제공, Body 파서 설정
app.set("view engine", "ejs"); // EJS를 뷰 엔진으로 설정하여 템플릿을 렌더링
app.set("views", path.join(__dirname, 'views')); // EJS 템플릿 파일들이 위치한 디렉토리를 지정

// '/public' 경로로 들어오는 요청을 public 폴더에서 정적 파일로 제공
app.use("/public", express.static(__dirname + '/public'));

// 요청 본문을 파싱할 때, URL 인코딩된 데이터를 처리하고 JSON 형식의 데이터를 처리
app.use(bodyParser.urlencoded({ extended: false })); // URL 인코딩된 데이터 처리
app.use(bodyParser.json()); // JSON 형식의 데이터 처리

// 라우터 설정
const router = require("./routes/index"); // 별도의 라우터 파일에서 설정한 라우터를 가져옴
app.use(router); // Express 앱에 라우터 적용

// MongoDB 연결 (비동기 방식으로 변경)
async function connectToDB() {
    try {
        // MongoDB에 비동기적으로 연결합니다.
        await mongoose.connect('mongodb://localhost:27017/node'); // 'node' 데이터베이스에 연결
        console.log("mongoDB Connected!"); // 연결 성공 시 콘솔에 메시지 출력

        // 연결이 성공하면 서버를 3000번 포트에서 실행
        app.listen(3000, function() {
            console.log("Server listening on port 3000!"); // 서버 실행 후 포트 출력
        });

    } catch (err) {
        // 연결 실패 시 에러 메시지 출력
        console.error("mongoDB Connection Error!", err);
    }
}

// MongoDB 연결 함수 호출
connectToDB(); // DB 연결 시도
