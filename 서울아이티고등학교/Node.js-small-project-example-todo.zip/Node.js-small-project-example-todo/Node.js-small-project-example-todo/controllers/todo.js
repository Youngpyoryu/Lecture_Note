// Model
const TodoTask = require("../models/todoTask"); // MongoDB와 연결된 TodoTask 모델 불러오기

// KST Setting
var moment = require('moment-timezone'); // 날짜와 시간 처리를 위한 moment 라이브러리 불러오기
moment.tz.setDefault("Asia/Seoul"); // 시간대를 한국 표준시(KST)로 설정

// Controller - 서비스 로직

/**
 * 첫 페이지
 * GET /todo
 * - DB에서 모든 할 일을 가져와 todo.ejs 뷰에 렌더링
 */
exports.get = async function (req, res) {
    try {
        console.log("------------!!Todo!!------------");
        // DB에서 모든 할 일 데이터를 가져오고 날짜 역순으로 정렬
        const tasks = await TodoTask.find({}).sort({ date: -1 });
        res.render("todo", { todoTasks: tasks }); // 뷰에 데이터 전달
    } catch (err) {
        console.error("==== Fail!! Fetch TodoTasks ====");
        console.error(err); // 오류 로그 출력
        res.status(500).send("Error fetching tasks"); // 클라이언트에 오류 메시지 반환
    }
};

/**
 * 작성
 * POST /todo/write
 * - 새로운 할 일을 추가
 */
exports.write = async function (req, res) {
    try {
        // 새로운 TodoTask 객체 생성
        const todoTask = new TodoTask({
            content: req.body.content, // 클라이언트가 전송한 내용
            date: moment().format("YYYY-MM-DD HH:mm:ss"), // 현재 한국 시간 설정
        });
        await todoTask.save(); // MongoDB에 저장
        console.log("==== Success!! Save New TodoTask ====");
        console.table([{ id: todoTask._id, content: todoTask.content, date: todoTask.date }]);
        res.redirect("/todo"); // 저장 후 메인 페이지로 리다이렉트
    } catch (err) {
        console.error("==== Fail!! Save TodoTask ====");
        console.error(err); // 오류 로그 출력
        res.status(500).send("Error saving task"); // 클라이언트에 오류 메시지 반환
    }
};

/**
 * 편집
 * GET /todo/edit/:id
 * - 특정 할 일을 편집하기 위해 해당 데이터와 함께 편집 페이지를 렌더링
 */
exports.edit = async function (req, res) {
    try {
        const id = req.params.id; // 요청에서 할 일 ID를 가져옴
        // DB에서 모든 할 일을 날짜 역순으로 가져오기
        const tasks = await TodoTask.find({}).sort({ date: -1 });
        res.render("todo-edit", { todoTasks: tasks, idTask: id }); // 데이터와 편집할 ID 전달
    } catch (err) {
        console.error("==== Fail!! Fetch Tasks for Editing ====");
        console.error(err); // 오류 로그 출력
        res.status(500).send("Error fetching tasks for editing"); // 클라이언트에 오류 메시지 반환
    }
};

/**
 * 수정
 * POST /todo/update/:id
 * - 특정 할 일의 내용을 업데이트
 */
exports.update = async function (req, res) {
    try {
        const id = req.params.id; // 요청에서 할 일 ID를 가져옴
        // MongoDB에서 해당 ID의 할 일 데이터를 업데이트
        await TodoTask.findByIdAndUpdate(id, { content: req.body.content });
        console.log("==== Success!! Update TodoTask ====");
        console.log(`id: ${id}\nchanged content: ${req.body.content}`);
        res.redirect("/todo"); // 업데이트 후 메인 페이지로 리다이렉트
    } catch (err) {
        console.error("==== Fail!! Update TodoTask ====");
        console.error(err); // 오류 로그 출력
        res.status(500).send("Error updating task"); // 클라이언트에 오류 메시지 반환
    }
};

/**
 * 삭제
 * POST /todo/remove/:id
 * - 특정 할 일을 삭제
 */
exports.remove = async function (req, res) {
    try {
        const id = req.params.id; // 요청에서 할 일 ID를 가져옴
        // MongoDB에서 해당 ID의 할 일을 삭제
        await TodoTask.findByIdAndRemove(id);
        console.log("==== Success!! Remove TodoTask ====");
        console.log(`id: ${id}`);
        res.redirect("/todo"); // 삭제 후 메인 페이지로 리다이렉트
    } catch (err) {
        console.error("==== Fail!! Remove TodoTask ====");
        console.error(err); // 오류 로그 출력
        res.status(500).send("Error removing task"); // 클라이언트에 오류 메시지 반환
    }
};
