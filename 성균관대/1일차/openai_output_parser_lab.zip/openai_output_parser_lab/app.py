import json
import streamlit as st
from openai import OpenAI
from pydantic import BaseModel, Field, ValidationError
from typing import List

from src.config import API_KEY, MODEL
from src.schemas import FINAL_CALC_SCHEMA, CALC_TOOL
from src.safe_eval import safe_eval_expr
from src.parser_utils import must_parse_json


# ---------- Pydantic model (Lab2에서 사용) ----------
class FinalCalcAnswer(BaseModel):
    expression: str
    value: float
    steps: List[str] = Field(min_length=1)
    assumptions: List[str]


# ---------- OpenAI client ----------
def get_client() -> OpenAI:
    # 요청하신 “코드에 직접 넣는 버전” (config.py에서 읽음)
    return OpenAI(api_key=API_KEY)


def call_structured(client: OpenAI, prompt: str) -> str:
    resp = client.responses.create(
        model=MODEL,
        input=prompt,
        text={
            "format": {
                "type": "json_schema",
                "strict": True,
                "name": FINAL_CALC_SCHEMA["name"],
                "schema": FINAL_CALC_SCHEMA["schema"],
            }
        },
    )
    return resp.output_text


# ---------- UI ----------
st.set_page_config(page_title="OpenAI Output Parsing Lab", layout="wide")
st.title("OpenAI Output Parsing Lab (Streamlit)")
st.caption("Lab1: json_schema 고정 출력 → 파싱 / Lab2: Pydantic 검증+repair / Lab3: Tool calling → 최종 json_schema")

with st.sidebar:
    st.subheader("Current settings")
    st.code(f"MODEL = {MODEL}\nAPI_KEY = {'SET' if API_KEY and API_KEY.startswith('sk-') else 'NOT SET'}")
    st.warning("API 키 하드코딩은 유출 위험이 큽니다. 커밋/공유 금지.", icon="⚠️")


tab1, tab2, tab3 = st.tabs(["Lab 1) json_schema → parse", "Lab 2) validate+repair", "Lab 3) tools → structured final"])


# ---------- Lab 1 ----------
with tab1:
    st.subheader("Lab 1: 모델 최종 출력을 json_schema로 고정하고, JSON 파싱만 수행")
    default_prompt = "Compute (7.5 - 2.5) * (10 / 4). Provide steps."
    prompt = st.text_area("Prompt", value=default_prompt, height=120)

    if st.button("Run Lab 1", type="primary"):
        client = get_client()
        try:
            raw = call_structured(client, prompt)
            st.markdown("### Raw output_text (JSON string)")
            st.code(raw, language="json")

            data = must_parse_json(raw)
            st.markdown("### Parsed dict")
            st.json(data)

        except Exception as e:
            st.error(str(e))


# ---------- Lab 2 ----------
with tab2:
    st.subheader("Lab 2: json_schema 출력 + Pydantic 앱 레벨 검증 + 실패 시 repair 요청")
    default_prompt = "Compute (12/5) + (3.1*2). Provide steps clearly."
    prompt2 = st.text_area("Prompt", value=default_prompt, height=120)

    colA, colB = st.columns(2)
    with colA:
        st.write("앱 레벨 제약 예시: steps는 최소 1개")
        st.code("steps: List[str] = Field(min_length=1)")

    if st.button("Run Lab 2", type="primary"):
        client = get_client()

        try:
            raw1 = call_structured(client, prompt2)
            st.markdown("### First response (raw JSON)")
            st.code(raw1, language="json")

            data1 = must_parse_json(raw1)

            try:
                obj = FinalCalcAnswer(**data1)
                st.success("Pydantic validation: PASS")
                st.json(obj.model_dump())
            except ValidationError as ve:
                st.warning("Pydantic validation: FAIL → repair 요청 수행", icon="🛠️")
                st.code(str(ve))

                repair_prompt = (
                    "Your previous JSON failed app-level validation.\n"
                    f"Validation error:\n{ve}\n\n"
                    "Return a corrected JSON that matches the SAME schema exactly."
                )
                raw2 = call_structured(client, repair_prompt)
                st.markdown("### Repaired response (raw JSON)")
                st.code(raw2, language="json")

                data2 = must_parse_json(raw2)
                obj2 = FinalCalcAnswer(**data2)
                st.success("Repair validation: PASS")
                st.json(obj2.model_dump())

        except Exception as e:
            st.error(str(e))


# ---------- Lab 3 ----------
with tab3:
    st.subheader("Lab 3: Tool calling으로 계산은 코드가 수행 → 최종 응답은 json_schema로 고정")
    st.write("Flow: (1) 모델이 calc tool 호출 → (2) 코드가 safe_eval로 계산 → (3) previous_response_id로 컨텍스트 이어서 최종 json_schema 출력")

    expr = st.text_input("Expression (tool이 계산할 대상)", value="((3+5)*2)/4")
    user_prompt = st.text_area(
        "User prompt (모델에게 tool 호출을 유도하는 문장)",
        value="Compute the expression using the calc tool and explain step-by-step.",
        height=100,
    )

    if st.button("Run Lab 3", type="primary"):
        client = get_client()

        try:
            # 1) tool call 유도 (expression도 같이 알려주면 tool 사용이 더 안정적)
            resp1 = client.responses.create(
                model=MODEL,
                input=f"{user_prompt}\nExpression: {expr}",
                tools=[CALC_TOOL],
            )

            st.markdown("### Step 1) resp1.output (tool call 확인)")
            debug_list = []
            for it in resp1.output:
                debug_list.append({
                    "type": getattr(it, "type", None),
                    "name": getattr(it, "name", None),
                    "call_id": getattr(it, "call_id", None),
                })
            st.json(debug_list)

            # 2) function_call 찾아서 계산
            tool_outputs = []
            tool_called = False

            for item in resp1.output:
                if item.type == "function_call" and item.name == "calc":
                    tool_called = True
                    args = json.loads(item.arguments)
                    tool_expr = args["expression"]  # 모델이 요청한 expression
                    value = safe_eval_expr(tool_expr)

                    tool_outputs.append({
                        "type": "function_call_output",
                        "call_id": item.call_id,
                        "output": json.dumps({"expression": tool_expr, "value": value}),
                    })

                    st.markdown("### Step 2) Tool execution (safe_eval 결과)")
                    st.json({"expression": tool_expr, "value": value})

            if not tool_called:
                st.error("모델이 calc tool을 호출하지 않았습니다. 프롬프트를 더 강하게 쓰거나(예: 'You MUST call calc'), 모델/툴 스키마를 점검하세요.")
                st.stop()

            # 3) previous_response_id로 resp1의 tool call 컨텍스트를 이어받고 tool output만 전달
            resp2 = client.responses.create(
                model=MODEL,
                previous_response_id=resp1.id,
                input=tool_outputs,
                instructions="Use the tool output for the numeric value. Provide concise steps.",
                text={
                    "format": {
                        "type": "json_schema",
                        "strict": True,
                        "name": FINAL_CALC_SCHEMA["name"],
                        "schema": FINAL_CALC_SCHEMA["schema"],
                    }
                },
            )

            raw = resp2.output_text
            st.markdown("### Step 3) Final structured output (raw JSON)")
            st.code(raw, language="json")

            data = must_parse_json(raw)
            st.markdown("### Parsed final dict")
            st.json(data)

        except Exception as e:
            st.error(str(e))
