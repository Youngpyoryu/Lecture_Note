# src/config.py
# WARNING: 절대 커밋/공유 금지

API_KEY = "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"
MODEL = "gpt-4o-mini"
