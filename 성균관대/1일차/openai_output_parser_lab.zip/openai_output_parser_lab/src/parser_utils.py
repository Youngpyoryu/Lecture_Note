# src/parser_utils.py
import json
from typing import Any, Dict

def must_parse_json(text: str) -> Dict[str, Any]:
    """Strict JSON parser: raise if invalid JSON."""
    return json.loads(text)

