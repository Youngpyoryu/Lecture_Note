# src/run_01_json_schema_basic.py
from openai import OpenAI
from src.config import API_KEY, MODEL
from src.schemas import FINAL_CALC_SCHEMA
from src.parser_utils import must_parse_json

client = OpenAI(api_key=API_KEY)

def main():
    prompt = "Compute (7.5 - 2.5) * (10 / 4). Provide steps."

    resp = client.responses.create(
        model=MODEL,
        input=prompt,
        text={
            "format": {
                "type": "json_schema",
                "strict": True,
                "name": FINAL_CALC_SCHEMA["name"],
                "schema": FINAL_CALC_SCHEMA["schema"],
            }
        },
    )

    raw = resp.output_text         # JSON 문자열이 와야 함
    data = must_parse_json(raw)    # dict로 변환

    print("RAW JSON:\n", raw)
    print("\nPARSED DICT:\n", data)

if __name__ == "__main__":
    main()
