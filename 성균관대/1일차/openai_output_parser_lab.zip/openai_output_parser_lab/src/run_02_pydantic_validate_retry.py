# src/run_02_pydantic_validate_retry.py
from openai import OpenAI
from pydantic import BaseModel, Field, ValidationError
from typing import List

from src.config import API_KEY, MODEL
from src.schemas import FINAL_CALC_SCHEMA
from src.parser_utils import must_parse_json

client = OpenAI(api_key=API_KEY)

class FinalCalcAnswer(BaseModel):
    expression: str
    value: float
    steps: List[str] = Field(min_length=1)  # 앱 레벨 제약(예: 최소 1개 step)
    assumptions: List[str]

def call_structured(prompt: str) -> str:
    resp = client.responses.create(
        model=MODEL,
        input=prompt,
        text={
            "format": {
                "type": "json_schema",
                "strict": True,
                "name": FINAL_CALC_SCHEMA["name"],
                "schema": FINAL_CALC_SCHEMA["schema"],
            }
        },
    )
    return resp.output_text

def main():
    prompt = "Compute (12/5) + (3.1*2). Provide steps clearly."

    raw = call_structured(prompt)
    data = must_parse_json(raw)

    try:
        obj = FinalCalcAnswer(**data)
        print("VALIDATED:\n", obj.model_dump())
        return
    except ValidationError as e:
        # 스키마는 맞아도, 앱 제약(steps 최소 길이 등)에서 실패할 수 있어 재요청 패턴을 둠
        repair_prompt = (
            "Your previous JSON failed app-level validation.\n"
            f"Validation error:\n{e}\n\n"
            "Return a corrected JSON that matches the SAME schema exactly."
        )
        raw2 = call_structured(repair_prompt)
        data2 = must_parse_json(raw2)
        obj2 = FinalCalcAnswer(**data2)
        print("REPAIRED + VALIDATED:\n", obj2.model_dump())

if __name__ == "__main__":
    main()
