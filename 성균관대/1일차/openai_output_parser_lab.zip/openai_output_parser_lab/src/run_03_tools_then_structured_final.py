# src/run_03_tools_then_structured_final.py
import json
from openai import OpenAI

from src.config import API_KEY, MODEL
from src.schemas import CALC_TOOL, FINAL_CALC_SCHEMA
from src.safe_eval import safe_eval_expr
from src.parser_utils import must_parse_json

client = OpenAI(api_key=API_KEY)


def main():
    # (A) 모델이 calc tool을 호출하도록 요청
    resp1 = client.responses.create(
        model=MODEL,
        input="Compute ((3+5)*2)/4 and explain step-by-step.",
        tools=[CALC_TOOL],
    )

    # (디버깅용) resp1.output을 찍어보면 item.type, call_id 등을 확인 가능
    # print([{"type": it.type, "name": getattr(it, "name", None), "call_id": getattr(it, "call_id", None)} for it in resp1.output])

    # (B) 모델이 요청한 function_call을 찾아 안전하게 계산
    tool_outputs = []
    for item in resp1.output:
        if item.type == "function_call" and item.name == "calc":
            args = json.loads(item.arguments)
            expr = args["expression"]
            value = safe_eval_expr(expr)

            tool_outputs.append(
                {
                    "type": "function_call_output",
                    "call_id": item.call_id,
                    "output": json.dumps({"expression": expr, "value": value}),
                }
            )

    if not tool_outputs:
        raise RuntimeError(
            "Model did not call the calc tool. "
            "Try adding stronger instruction or check your tools schema."
        )

    # (C) 핵심: previous_response_id로 resp1 컨텍스트(=tool call)를 이어받은 뒤,
    # input에는 tool output만 전달
    resp2 = client.responses.create(
        model=MODEL,
        previous_response_id=resp1.id,
        input=tool_outputs,
        text={
            "format": {
                "type": "json_schema",
                "strict": True,
                "name": FINAL_CALC_SCHEMA["name"],
                "schema": FINAL_CALC_SCHEMA["schema"],
            }
        },
        instructions="Use the tool output for the numeric value. Provide concise steps.",
    )

    raw = resp2.output_text
    data = must_parse_json(raw)
    print("FINAL:\n", data)


if __name__ == "__main__":
    main()
