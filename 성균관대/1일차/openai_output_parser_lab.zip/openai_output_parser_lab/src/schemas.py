# src/schemas.py

# 최종 응답(모델의 "최종 출력")을 스키마로 고정하기 위한 JSON Schema
FINAL_CALC_SCHEMA = {
    "name": "FinalCalcAnswer",
    "schema": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "expression": {"type": "string"},
            "value": {"type": "number"},
            "steps": {"type": "array", "items": {"type": "string"}},
            "assumptions": {"type": "array", "items": {"type": "string"}},
        },
        "required": ["expression", "value", "steps", "assumptions"],
    },
}

# 함수 호출(tool calling)용 스키마: 계산기
CALC_TOOL = {
    "type": "function",
    "name": "calc",
    "description": "Evaluate a simple arithmetic expression safely. Supports +, -, *, /, parentheses.",
    "parameters": {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "expression": {"type": "string", "description": "e.g., '(3+5)*2/4'"},
        },
        "required": ["expression"],
    },
}
