## app.py
### 의도: Streamlit으로 RAG 챗봇 UI를 제공하고, 전체 파이프라인(문서 입력 → 인덱스 생성 → 질문/검색 → 답변)을 한 화면에서 실행한다.
### 핵심: 사용자가 PDF/Web/Notes를 선택해 입력하고, chunk_size/overlap/top_k 및 고급 옵션(rewrite/MMR/rerank)을 조절한다.
### 상태관리: st.session_state에 API Key, chunks, 인덱스(벡터), 인덱스 메타 정보를 저장해 재사용한다.
### 출력: Retrieved Evidence(출처/페이지/chunk_id 포함)와 LLM Answer를 함께 보여줘 “근거 기반”을 눈으로 확인한다.
import streamlit as st
from openai import OpenAI

from loaders import load_pdf_pages, load_web_pages, load_notes_pages, chunk_pages
from rag_core import build_index, retrieve, answer_with_rag

st.set_page_config(page_title="RAG Chatbot (No FAISS)", layout="wide")
st.title("RAG Chatbot (No FAISS) — BruteForce Retrieval")

with st.sidebar:
    st.header("0) OpenAI API Key")
    api_key = st.text_input("OPENAI_API_KEY", type="password", placeholder="sk-...")
    if api_key:
        st.session_state["OPENAI_API_KEY"] = api_key


def get_client_from_session() -> OpenAI:
    key = st.session_state.get("OPENAI_API_KEY", "").strip()
    if not key.startswith("sk-"):
        raise RuntimeError("API Key가 필요합니다. 사이드바에 sk-로 시작하는 키를 입력하세요.")
    return OpenAI(api_key=key)


with st.sidebar:
    st.header("1) 문서 입력")
    mode = st.radio("소스 선택", ["PDF 업로드", "웹 URL", "노트 입력"], index=0)

    pages = []
    source_label = ""

    if mode == "PDF 업로드":
        pdf = st.file_uploader("PDF 파일", type=["pdf"])
        if pdf is not None:
            pages = load_pdf_pages(pdf)
            source_label = getattr(pdf, "name", "uploaded.pdf")

    elif mode == "웹 URL":
        url = st.text_input("URL")
        if url:
            pages = load_web_pages(url)
            source_label = url

    else:
        note_text = st.text_area("노트/메모 텍스트", height=220)
        if note_text.strip():
            pages = load_notes_pages(note_text)
            source_label = "notes"

    st.divider()
    st.header("2) 청킹/인덱싱")
    chunk_size = st.slider("chunk_size", 300, 1500, 800, 50)
    overlap = st.slider("overlap", 0, 400, 120, 20)
    build_btn = st.button("인덱스 생성", type="primary")

    st.divider()
    st.header("3) Retrieval 고급 옵션")
    use_rewrite = st.checkbox("Query rewrite", value=True)
    use_mmr = st.checkbox("MMR (중복 감소)", value=True)
    mmr_lambda = st.slider("MMR lambda(관련성↔다양성)", 0.0, 1.0, 0.5, 0.05)
    use_rerank = st.checkbox("LLM Re-rank", value=True)
    fetch_k = st.slider("fetch_k(후보 수)", 8, 80, 20, 4)

# session states
if "index_obj" not in st.session_state:
    st.session_state.index_obj = None
if "chunks" not in st.session_state:
    st.session_state.chunks = []
if "index_meta" not in st.session_state:
    st.session_state.index_meta = None

# build index
if build_btn:
    if not pages:
        st.error("문서가 비어있습니다. PDF/URL/노트를 입력하세요.")
    else:
        try:
            client = get_client_from_session()
            chunks = chunk_pages(pages, chunk_size=chunk_size, overlap=overlap)
            st.session_state.chunks = chunks
            st.session_state.index_obj = build_index(client, chunks)
            st.session_state.index_meta = {
                "mode": mode,
                "source": source_label,
                "chunk_size": chunk_size,
                "overlap": overlap,
                "num_pages": len(pages),
                "num_chunks": len(chunks),
            }
            st.success(f"인덱스 생성 완료: chunks={len(chunks)}")
        except Exception as e:
            st.error(str(e))

# main
col1, col2 = st.columns([1, 1])

with col1:
    st.header("4) 질문")
    if st.session_state.index_meta:
        m = st.session_state.index_meta
        st.info(
            f"현재 인덱스: pages={m['num_pages']} | chunks={m['num_chunks']} | "
            f"{m['mode']} | {m['source']} | chunk_size={m['chunk_size']} | overlap={m['overlap']}"
        )

    q = st.text_input("질문을 입력하세요", placeholder="예: RAG가 hallucination을 줄이는 원리는?")
    top_k = st.slider("top_k", 1, 8, 4, 1)
    ask = st.button("검색+응답")

with col2:
    st.header("Chunk 미리보기")
    chunks = st.session_state.chunks
    if chunks:
        st.write(f"총 {len(chunks)} chunks")
        idx = st.slider("미리볼 chunk_id", 0, len(chunks) - 1, 0, 1)
        st.json(chunks[idx]["meta"])
        st.code(chunks[idx]["text"][:1200])

# ask
if ask:
    if st.session_state.index_obj is None:
        st.error("먼저 인덱스를 생성하세요.")
    elif not q.strip():
        st.error("질문을 입력하세요.")
    else:
        try:
            client = get_client_from_session()
            search_query, hits = retrieve(
                client,
                st.session_state.index_obj,
                q,
                top_k=top_k,
                fetch_k=fetch_k,
                use_rewrite=use_rewrite,
                use_mmr=use_mmr,
                mmr_lambda=mmr_lambda,
                use_rerank=use_rerank,
            )
            st.caption(f"검색용 질의(rewrite): {search_query}")

            st.subheader("Retrieved Evidence")
            for i, (ch, score) in enumerate(hits, 1):
                meta = ch.get("meta", {})
                src = meta.get("source") or meta.get("url") or "unknown"
                page = meta.get("page", "")
                cid = meta.get("chunk_id", "")
                title = f"[{i}] {src} p{page} c{cid} | score={score:.3f}"
                with st.expander(title):
                    st.json(meta)
                    st.write(ch.get("text", ""))

            st.subheader("LLM Answer")
            ans = answer_with_rag(client, q, hits)
            st.write(ans)

        except Exception as e:
            st.error(str(e))
