# loaders.py
### 의도: 서로 다른 입력(PDF/Web/Notes)을 공통 포맷(pages)으로 통일하고, 이후 검색을 위한 chunks(meta 포함)를 생성한다.
### 핵심: PDF는 페이지 단위로 텍스트를 추출하고 source/page 메타를 붙이며, Web은 url, Notes는 source=notes로 메타를 붙인다.
### 청킹: chunk_pages()가 chunk_size/overlap 규칙으로 텍스트를 잘라 chunk_id를 부여한다.
### 효과: evidence가 어디서 왔는지 추적 가능해지고, RAG의 검증 가능성이 올라간다.

from __future__ import annotations
from typing import List, Dict, Any
import re

import httpx
from bs4 import BeautifulSoup
from pypdf import PdfReader


def _clean_text(text: str) -> str:
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def load_pdf_pages(file_obj) -> List[Dict[str, Any]]:
    reader = PdfReader(file_obj)
    source = getattr(file_obj, "name", "uploaded.pdf")

    pages: List[Dict[str, Any]] = []
    for i, page in enumerate(reader.pages, start=1):
        t = page.extract_text() or ""
        t = _clean_text(t)
        if t:
            pages.append({"text": t, "meta": {"source": source, "page": i}})
    return pages


def load_web_pages(url: str, timeout: float = 15.0) -> List[Dict[str, Any]]:
    r = httpx.get(url, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")

    for tag in soup(["script", "style", "noscript", "header", "footer", "nav"]):
        tag.decompose()

    text = soup.get_text(separator="\n")
    text = _clean_text(text)
    return [{"text": text, "meta": {"url": url}}] if text else []


def load_notes_pages(text: str) -> List[Dict[str, Any]]:
    text = _clean_text(text or "")
    return [{"text": text, "meta": {"source": "notes"}}] if text else []


def chunk_pages(
    pages: List[Dict[str, Any]],
    chunk_size: int = 800,
    overlap: int = 120
) -> List[Dict[str, Any]]:
    chunks: List[Dict[str, Any]] = []
    chunk_id = 0

    for p in pages:
        text = re.sub(r"\s+", " ", (p.get("text") or "")).strip()
        if not text:
            continue

        meta_base = dict(p.get("meta", {}))

        start = 0
        while start < len(text):
            end = min(len(text), start + chunk_size)
            piece = text[start:end].strip()

            meta = dict(meta_base)
            meta["chunk_id"] = chunk_id

            chunks.append({"text": piece, "meta": meta})
            chunk_id += 1

            if end == len(text):
                break
            start = max(0, end - overlap)

    return chunks
