# brute-force : 완전탐색 알고리즘. 즉, 가능한 모든 경우의 수를 모두 탐색하면서 요구조건에 충족되는 결과 from __future__ import annotations
### 의도: 임베딩 기반 검색의 핵심 로직(임베딩 생성 → 유사도 계산 → top-k 선택)과, evidence 기반 답변 생성을 담당한다.
### 검색: FAISS 없이도 임베딩 벡터를 정규화한 뒤, 코사인 유사도(내적)로 후보를 점수화하여 top-k를 선택한다.
### 품질개선(옵션): Query rewrite로 검색 질의를 정리하고, MMR로 중복을 줄이며, LLM rerank로 “직접 답하는 근거” 순으로 재정렬한다.
### 답변: 선택된 근거를 citation([source|p?|c?]) 형태로 제공하여, 답변이 근거에 연결되도록 강제한다.

from dataclasses import dataclass
from typing import List, Tuple, Dict, Any, Optional
import os
import json

import numpy as np
from openai import OpenAI

EMBED_MODEL = "text-embedding-3-small"
CHAT_MODEL = "gpt-4-0613"


def get_client() -> OpenAI:
    key = os.getenv("OPENAI_API_KEY") or ""
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    return OpenAI(api_key=key)


def embed_texts(client: OpenAI, texts: List[str]) -> np.ndarray:
    resp = client.embeddings.create(model=EMBED_MODEL, input=texts)
    vecs = np.array([d.embedding for d in resp.data], dtype=np.float32)
    return vecs


def _normalize_rows(mat: np.ndarray) -> np.ndarray:
    denom = np.linalg.norm(mat, axis=1, keepdims=True) + 1e-12
    return mat / denom


def _normalize(vec: np.ndarray) -> np.ndarray:
    return vec / (np.linalg.norm(vec) + 1e-12)


@dataclass
class VectorIndex:
    vectors: np.ndarray                 # (N, d) normalized
    chunks: List[Dict[str, Any]]        # [{"text":..., "meta":...}]


def build_index(client: OpenAI, chunks: List[Dict[str, Any]]) -> VectorIndex:
    texts = [c["text"] for c in chunks]
    vecs = embed_texts(client, texts)
    vecs = _normalize_rows(vecs)
    return VectorIndex(vectors=vecs, chunks=chunks)


# -----------------------
# Query rewrite
# -----------------------
def rewrite_query(client: OpenAI, query: str) -> str:
    prompt = f"""
You rewrite user questions into a SHORT search query for retrieval.
Rules:
- Keep key entities/constraints/technical terms.
- Remove filler. Output ONE line only.
- Do not answer the question.

User question:
{query}

Search query:
""".strip()

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.0,
        max_tokens=64,
    )
    out = r.choices[0].message.content.strip()
    return out if out else query


# -----------------------
# MMR selection (works with brute-force too)
# -----------------------
def _mmr_select(
    qvec: np.ndarray,           # [d] normalized
    cand_ids: List[int],
    vectors: np.ndarray,        # [N, d] normalized
    k: int,
    lambda_mult: float = 0.5
) -> List[int]:
    selected: List[int] = []
    remaining = cand_ids.copy()
    q_sims = {i: float(np.dot(qvec, vectors[i])) for i in remaining}

    while remaining and len(selected) < k:
        best_id, best_val = None, -1e9
        for cid in remaining:
            rel = q_sims[cid]
            div = 0.0 if not selected else max(float(np.dot(vectors[cid], vectors[sid])) for sid in selected)
            mmr = lambda_mult * rel - (1.0 - lambda_mult) * div
            if mmr > best_val:
                best_val, best_id = mmr, cid
        selected.append(best_id)
        remaining.remove(best_id)
    return selected


# -----------------------
# LLM rerank
# -----------------------
def rerank_llm(client: OpenAI, query: str, candidates: List[Dict[str, Any]], top_k: int) -> List[int]:
    items = []
    for i, c in enumerate(candidates):
        meta = c.get("meta", {})
        src = meta.get("source") or meta.get("url") or "unknown"
        page = meta.get("page", "")
        cid = meta.get("chunk_id", "")
        items.append({
            "i": i, "source": src, "page": page, "chunk_id": cid,
            "text": c.get("text", "")[:1200],
        })

    prompt = f"""
You are a reranker. Rank candidates by how directly they answer the question.
Return JSON only: {{"ranked":[0,1,2,...]}}.

Question:
{query}

Candidates (JSON):
{json.dumps(items, ensure_ascii=False)}
""".strip()

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.0,
        max_tokens=256,
    )
    out = r.choices[0].message.content.strip()

    try:
        ranked = json.loads(out).get("ranked", [])
        ranked = [i for i in ranked if isinstance(i, int)]
        if ranked:
            return ranked[:top_k]
    except Exception:
        pass
    return list(range(min(top_k, len(candidates))))


def _cite(meta: Dict[str, Any]) -> str:
    src = meta.get("source") or meta.get("url") or "unknown"
    page = meta.get("page", "")
    cid = meta.get("chunk_id", "")
    parts = [str(src)]
    if page != "":
        parts.append(f"p{page}")
    if cid != "":
        parts.append(f"c{cid}")
    return "[" + "|".join(parts) + "]"


# -----------------------
# Retrieval: brute-force + options
# -----------------------
def retrieve(
    client: OpenAI,
    index: VectorIndex,
    query: str,
    top_k: int = 4,
    fetch_k: Optional[int] = None,
    use_rewrite: bool = True,
    use_mmr: bool = True,
    mmr_lambda: float = 0.5,
    use_rerank: bool = True,
) -> Tuple[str, List[Tuple[Dict[str, Any], float]]]:
    search_query = rewrite_query(client, query) if use_rewrite else query

    qv = embed_texts(client, [search_query])[0]
    qv = _normalize(qv)

    scores = index.vectors @ qv  # (N,)
    fk = fetch_k if fetch_k is not None else max(top_k * 4, 20)
    fk = min(fk, len(scores))

    cand_ids = np.argsort(-scores)[:fk].tolist()

    if use_mmr and len(cand_ids) > top_k:
        picked_ids = _mmr_select(qv, cand_ids, index.vectors, k=top_k, lambda_mult=mmr_lambda)
    else:
        picked_ids = cand_ids[:top_k]

    picked = [(index.chunks[i], float(scores[i])) for i in picked_ids]

    if use_rerank and len(picked) > 1:
        cand_chunks = [c for (c, _) in picked]
        order = rerank_llm(client, query, cand_chunks, top_k=len(cand_chunks))
        picked = [picked[i] for i in order]

    return search_query, picked


def answer_with_rag(client: OpenAI, query: str, retrieved: List[Tuple[Dict[str, Any], float]]) -> str:
    blocks = []
    for i, (ch, score) in enumerate(retrieved, start=1):
        blocks.append(f"[{i}] {_cite(ch.get('meta', {}))} (score={score:.3f})\n{ch.get('text','')}")
    evidence = "\n\n".join(blocks)

    prompt = f"""
You are a RAG assistant. Use ONLY the provided evidence.
If evidence is insufficient, say what is missing and ask one clarifying question.
You MUST cite sources in the final answer using [source|p?|c?].

Question:
{query}

Evidence:
{evidence}

Write:
1) Evidence summary (3-6 bullets)
2) Final answer (concise, with citations)
""".strip()

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role":"user","content":prompt}],
        temperature=0.2,
        max_tokens=700,
    )
    return r.choices[0].message.content.strip()
