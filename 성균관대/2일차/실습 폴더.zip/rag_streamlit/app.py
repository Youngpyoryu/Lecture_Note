import streamlit as st
from openai import OpenAI

from loaders import load_pdf_text, load_web_text, chunk_text
from rag_core import build_faiss_index, retrieve, answer_with_rag

st.set_page_config(page_title="RAG Chatbot", layout="wide")
st.title("RAG Chatbot (PDF / Web / Notes)")

# --- API Key 입력 (Streamlit 실행 후 받기) ---
with st.sidebar:
    st.header("0) OpenAI API Key")
    api_key = st.text_input(
        "OPENAI_API_KEY",
        type="password",
        placeholder="sk-...",
        help="세션에만 저장됩니다. 새로고침/재실행 시 다시 입력 필요."
    )
    if api_key:
        st.session_state["OPENAI_API_KEY"] = api_key

def get_client_from_session() -> OpenAI:
    key = st.session_state.get("OPENAI_API_KEY", "").strip()
    if not key.startswith("sk-"):
        raise RuntimeError("API Key가 필요합니다. 사이드바에 sk-로 시작하는 키를 입력하세요.")
    return OpenAI(api_key=key)

# ---------------- 기존 사이드바 로직 ----------------
with st.sidebar:
    st.header("1) 문서 입력")
    mode = st.radio("소스 선택", ["PDF 업로드", "웹 URL", "노트 입력"], index=0)

    source_text = ""
    if mode == "PDF 업로드":
        pdf = st.file_uploader("PDF 파일", type=["pdf"])
        if pdf is not None:
            source_text = load_pdf_text(pdf)
    elif mode == "웹 URL":
        url = st.text_input("URL")
        if url:
            source_text = load_web_text(url)
    else:
        source_text = st.text_area("노트/메모 텍스트", height=220)

    st.divider()
    st.header("2) 청킹/인덱싱")
    chunk_size = st.slider("chunk_size", 300, 1500, 800, 50)
    overlap = st.slider("overlap", 0, 400, 120, 20)
    build_btn = st.button("인덱스 생성", type="primary")

# 상태
if "vindex" not in st.session_state:
    st.session_state.vindex = None
if "chunks" not in st.session_state:
    st.session_state.chunks = []

# 인덱스 생성
if build_btn:
    if not source_text.strip():
        st.error("문서 텍스트가 비어있습니다.")
    else:
        try:
            client = get_client_from_session()
        except Exception as e:
            st.error(str(e))
        else:
            chunks = chunk_text(source_text, chunk_size=chunk_size, overlap=overlap)
            st.session_state.chunks = chunks
            st.session_state.vindex = build_faiss_index(client, chunks)
            st.success(f"인덱스 생성 완료: chunks={len(chunks)}")

col1, col2 = st.columns([1, 1])

with col1:
    st.header("3) 질문")
    q = st.text_input("질문을 입력하세요", placeholder="예: RAG가 hallucination을 줄이는 원리는?")
    top_k = st.slider("top_k", 1, 8, 4, 1)
    ask = st.button("검색+응답")

with col2:
    st.header("Chunk 미리보기")
    if st.session_state.chunks:
        st.write(f"총 {len(st.session_state.chunks)} chunks")
        st.code(st.session_state.chunks[0][:1000])

if ask:
    if st.session_state.vindex is None:
        st.error("먼저 인덱스를 생성하세요.")
    elif not q.strip():
        st.error("질문을 입력하세요.")
    else:
        try:
            client = get_client_from_session()
        except Exception as e:
            st.error(str(e))
        else:
            hits = retrieve(client, st.session_state.vindex, q, top_k=top_k)

            st.subheader("Retrieved Evidence")
            for i, (txt, score) in enumerate(hits, 1):
                with st.expander(f"[{i}] score={score:.3f}"):
                    st.write(txt)

            st.subheader("LLM Answer")
            ans = answer_with_rag(client, q, hits)
            st.write(ans)
