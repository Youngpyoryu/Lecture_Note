from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple

import os
import numpy as np
import faiss
from openai import OpenAI


EMBED_MODEL = "text-embedding-3-small"
CHAT_MODEL = "gpt-4-0613"


def get_client() -> OpenAI:
    key = os.getenv("OPENAI_API_KEY") or ""
    if not key:
        # streamlit secrets 사용 시 app.py에서 env로 주입해도 됨
        raise RuntimeError("OPENAI_API_KEY is not set.")
    return OpenAI(api_key=key)


def embed_texts(client: OpenAI, texts: List[str]) -> np.ndarray:
    resp = client.embeddings.create(model=EMBED_MODEL, input=texts)
    vecs = np.array([d.embedding for d in resp.data], dtype=np.float32)
    # cosine 유사도 위해 L2 normalize
    faiss.normalize_L2(vecs)
    return vecs


@dataclass
class VectorIndex:
    index: faiss.Index
    chunks: List[str]


def build_faiss_index(client: OpenAI, chunks: List[str]) -> VectorIndex:
    vecs = embed_texts(client, chunks)
    dim = vecs.shape[1]
    index = faiss.IndexFlatIP(dim)  # inner product = cosine (normalized)
    index.add(vecs)
    return VectorIndex(index=index, chunks=chunks)


def retrieve(client: OpenAI, vindex: VectorIndex, query: str, top_k: int = 4) -> List[Tuple[str, float]]:
    qv = embed_texts(client, [query])
    scores, ids = vindex.index.search(qv, top_k)
    results = []
    for i, s in zip(ids[0], scores[0]):
        if i == -1:
            continue
        results.append((vindex.chunks[int(i)], float(s)))
    return results


def answer_with_rag(client: OpenAI, query: str, retrieved: List[Tuple[str, float]]) -> str:
    evidence = "\n\n".join([f"[{i+1}] {txt}" for i, (txt, _) in enumerate(retrieved)])

    prompt = f"""
You are a RAG assistant. Use ONLY the provided evidence.
If evidence is insufficient, say what is missing and ask one clarifying question.

Question:
{query}

Evidence:
{evidence}

Write:
1) Evidence summary (3-6 bullets)
2) Final answer (concise)
"""

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=400,
    )
    return r.choices[0].message.content.strip()
