# pages 기반 로딩 + 인덱스 정체성 표시 + chunk 선택 미리보기
## - 인덱스 생성 시 index_meta 저장:
### mode, source, chunk_size, overlap, num_chunks
### 화면에 “현재 인덱스 정보”를 표시
### chunk 미리보기에 chunk_id 선택 슬라이더 추가

import streamlit as st
from openai import OpenAI

from loaders import load_pdf_pages, load_web_pages, load_notes_pages, chunk_pages
from rag_core import build_faiss_index, retrieve, answer_with_rag

st.set_page_config(page_title="RAG Chatbot", layout="wide")
st.title("RAG Chatbot (PDF / Web / Notes)")

with st.sidebar:
    st.header("0) OpenAI API Key")
    api_key = st.text_input(
        "OPENAI_API_KEY",
        type="password",
        placeholder="sk-...",
        help="세션에만 저장됩니다. 새로고침/재실행 시 다시 입력 필요."
    )
    if api_key:
        st.session_state["OPENAI_API_KEY"] = api_key


def get_client_from_session() -> OpenAI:
    key = st.session_state.get("OPENAI_API_KEY", "").strip()
    if not key.startswith("sk-"):
        raise RuntimeError("API Key가 필요합니다. 사이드바에 sk-로 시작하는 키를 입력하세요.")
    return OpenAI(api_key=key)


with st.sidebar:
    st.header("1) 문서 입력")
    mode = st.radio("소스 선택", ["PDF 업로드", "웹 URL", "노트 입력"], index=0)

    pages = []
    source_label = ""

    if mode == "PDF 업로드":
        pdf = st.file_uploader("PDF 파일", type=["pdf"])
        if pdf is not None:
            pages = load_pdf_pages(pdf)
            source_label = getattr(pdf, "name", "uploaded.pdf")

    elif mode == "웹 URL":
        url = st.text_input("URL")
        if url:
            pages = load_web_pages(url)
            source_label = url

    else:
        note_text = st.text_area("노트/메모 텍스트", height=220)
        if note_text.strip():
            pages = load_notes_pages(note_text)
            source_label = "notes"

    st.divider()
    st.header("2) 청킹/인덱싱")
    chunk_size = st.slider("chunk_size", 300, 1500, 800, 50)
    overlap = st.slider("overlap", 0, 400, 120, 20)
    build_btn = st.button("인덱스 생성", type="primary")


# 상태 초기화
if "vindex" not in st.session_state:
    st.session_state.vindex = None
if "chunks" not in st.session_state:
    st.session_state.chunks = []
if "index_meta" not in st.session_state:
    st.session_state.index_meta = None


# 인덱스 생성
if build_btn:
    if not pages:
        st.error("문서가 비어있습니다. PDF/URL/노트를 입력하세요.")
    else:
        try:
            client = get_client_from_session()
            chunks = chunk_pages(pages, chunk_size=chunk_size, overlap=overlap)
            st.session_state.chunks = chunks
            st.session_state.vindex = build_faiss_index(client, chunks)
            st.session_state.index_meta = {
                "mode": mode,
                "source": source_label,
                "chunk_size": chunk_size,
                "overlap": overlap,
                "num_pages": len(pages),
                "num_chunks": len(chunks),
            }
            st.success(f"인덱스 생성 완료: chunks={len(chunks)}")
        except Exception as e:
            st.error(str(e))


col1, col2 = st.columns([1, 1])

with col1:
    st.header("3) 질문")

    if st.session_state.index_meta:
        st.info(
            f"현재 인덱스: {st.session_state.index_meta['mode']} | "
            f"{st.session_state.index_meta['source']} | "
            f"pages={st.session_state.index_meta['num_pages']} | "
            f"chunks={st.session_state.index_meta['num_chunks']} | "
            f"chunk_size={st.session_state.index_meta['chunk_size']} | "
            f"overlap={st.session_state.index_meta['overlap']}"
        )

    q = st.text_input("질문을 입력하세요", placeholder="예: RAG가 hallucination을 줄이는 원리는?")
    top_k = st.slider("top_k", 1, 8, 4, 1)
    ask = st.button("검색+응답")


with col2:
    st.header("Chunk 미리보기")
    chunks = st.session_state.chunks
    if chunks:
        st.write(f"총 {len(chunks)} chunks")
        idx = st.slider("미리볼 chunk_id", 0, len(chunks) - 1, 0, 1)
        st.json(chunks[idx]["meta"])
        st.code(chunks[idx]["text"][:1200])


if ask:
    if st.session_state.vindex is None:
        st.error("먼저 인덱스를 생성하세요.")
    elif not q.strip():
        st.error("질문을 입력하세요.")
    else:
        try:
            client = get_client_from_session()
            hits = retrieve(client, st.session_state.vindex, q, top_k=top_k)

            st.subheader("Retrieved Evidence")
            for i, (ch, score) in enumerate(hits, 1):
                meta = ch.get("meta", {})
                src = meta.get("source") or meta.get("url") or "unknown"
                page = meta.get("page", "")
                cid = meta.get("chunk_id", "")
                title = f"[{i}] {src} p{page} c{cid} | score={score:.3f}"

                with st.expander(title):
                    st.json(meta)
                    st.write(ch.get("text", ""))

            st.subheader("LLM Answer")
            ans = answer_with_rag(client, q, hits)
            st.write(ans)

        except Exception as e:
            st.error(str(e))
