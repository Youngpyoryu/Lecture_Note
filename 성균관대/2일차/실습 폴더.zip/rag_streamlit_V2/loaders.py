# 메타데이터 포함("페이지 리스트"+ Chunking)
## PDF: 페이지별로 text+meta(source,page) 생성
## Web: text+meta(url)
## Notes: text+meta(source="notes")
## chunk_pages(): chunk_id를 부여하여 디버깅/인용에 활용
from __future__ import annotations
from typing import List, Dict, Any, Union
import re

import httpx
from bs4 import BeautifulSoup
from pypdf import PdfReader


def _clean_text(text: str) -> str:
    # 공백 정리: 너무 공격적으로 한 줄로 만들면 문서 구조가 망가질 수 있어 완만하게 정리
    text = text.replace("\x00", " ")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def load_pdf_pages(file_obj) -> List[Dict[str, Any]]:
    """
    Returns:
      [{"text": "...", "meta": {"source": "file.pdf", "page": 1}}, ...]
    """
    reader = PdfReader(file_obj)
    source = getattr(file_obj, "name", "uploaded.pdf")

    pages: List[Dict[str, Any]] = []
    for i, page in enumerate(reader.pages, start=1):
        t = page.extract_text() or ""
        t = _clean_text(t)
        if not t:
            continue
        pages.append({"text": t, "meta": {"source": source, "page": i}})
    return pages


def load_web_pages(url: str, timeout: float = 15.0) -> List[Dict[str, Any]]:
    """
    Returns:
      [{"text": "...", "meta": {"url": "<url>"}}]
    """
    r = httpx.get(url, timeout=timeout, follow_redirects=True)
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")

    for tag in soup(["script", "style", "noscript", "header", "footer", "nav"]):
        tag.decompose()

    text = soup.get_text(separator="\n")
    text = _clean_text(text)
    return [{"text": text, "meta": {"url": url}}] if text else []


def load_notes_pages(text: str) -> List[Dict[str, Any]]:
    text = _clean_text(text or "")
    return [{"text": text, "meta": {"source": "notes"}}] if text else []


def chunk_pages(
    pages: List[Dict[str, Any]],
    chunk_size: int = 800,
    overlap: int = 120
) -> List[Dict[str, Any]]:
    """
    Returns:
      [{"text": "chunk...", "meta": {..., "chunk_id": 0}}, ...]
    """
    chunks: List[Dict[str, Any]] = []
    chunk_id = 0

    for p in pages:
        text = re.sub(r"\s+", " ", (p.get("text") or "")).strip()
        if not text:
            continue

        meta_base = dict(p.get("meta", {}))

        start = 0
        while start < len(text):
            end = min(len(text), start + chunk_size)
            piece = text[start:end].strip()

            meta = dict(meta_base)
            meta["chunk_id"] = chunk_id

            chunks.append({"text": piece, "meta": meta})
            chunk_id += 1

            if end == len(text):
                break
            start = max(0, end - overlap)

    return chunks
