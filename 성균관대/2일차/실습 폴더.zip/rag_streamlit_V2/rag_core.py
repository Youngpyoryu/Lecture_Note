# chunks를 “문자열”이 아니라 “dict(text/meta)”로 다룸
## VectorIndex.chunks를 List[str] → List[dict(text/meta)]로 변경
## retrieve 결과도 chunk dict + score 반환
## answer_with_rag에서 citation을 강제
from __future__ import annotations
from dataclasses import dataclass
from typing import List, Tuple, Dict, Any

import os
import numpy as np
import faiss
from openai import OpenAI

EMBED_MODEL = "text-embedding-3-small"
CHAT_MODEL = "gpt-4-0613"


def get_client() -> OpenAI:
    key = os.getenv("OPENAI_API_KEY") or ""
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    return OpenAI(api_key=key)


def embed_texts(client: OpenAI, texts: List[str]) -> np.ndarray:
    resp = client.embeddings.create(model=EMBED_MODEL, input=texts)
    vecs = np.array([d.embedding for d in resp.data], dtype=np.float32)
    faiss.normalize_L2(vecs)
    return vecs


@dataclass
class VectorIndex:
    index: faiss.Index
    chunks: List[Dict[str, Any]]  # each: {"text":..., "meta":...}


def build_faiss_index(client: OpenAI, chunks: List[Dict[str, Any]]) -> VectorIndex:
    texts = [c["text"] for c in chunks]
    vecs = embed_texts(client, texts)
    dim = vecs.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(vecs)
    return VectorIndex(index=index, chunks=chunks)


def retrieve(
    client: OpenAI,
    vindex: VectorIndex,
    query: str,
    top_k: int = 4
) -> List[Tuple[Dict[str, Any], float]]:
    qv = embed_texts(client, [query])
    scores, ids = vindex.index.search(qv, top_k)

    results: List[Tuple[Dict[str, Any], float]] = []
    for i, s in zip(ids[0], scores[0]):
        if i == -1:
            continue
        results.append((vindex.chunks[int(i)], float(s)))
    return results


def _format_citation(meta: Dict[str, Any]) -> str:
    src = meta.get("source") or meta.get("url") or "unknown"
    page = meta.get("page")
    cid = meta.get("chunk_id")

    parts = [str(src)]
    if page is not None:
        parts.append(f"p{page}")
    if cid is not None:
        parts.append(f"c{cid}")
    return "[" + "|".join(parts) + "]"


def answer_with_rag(
    client: OpenAI,
    query: str,
    retrieved: List[Tuple[Dict[str, Any], float]]
) -> str:
    blocks = []
    for i, (ch, score) in enumerate(retrieved, start=1):
        cite = _format_citation(ch.get("meta", {}))
        blocks.append(f"[{i}] {cite} (score={score:.3f})\n{ch.get('text','')}")
    evidence = "\n\n".join(blocks)

    prompt = f"""
You are a RAG assistant. Use ONLY the provided evidence.
If evidence is insufficient, say what is missing and ask one clarifying question.
You MUST cite sources in the final answer using the citation format like [source|p3|c12].

Question:
{query}

Evidence:
{evidence}

Write:
1) Evidence summary (3-6 bullets)
2) Final answer (concise, with citations)
""".strip()

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=500,
    )
    return r.choices[0].message.content.strip()
