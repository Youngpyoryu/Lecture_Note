# loaders.py
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Dict, Any
import re
import io

from pypdf import PdfReader
import requests
from bs4 import BeautifulSoup


@dataclass
class Document:
    # - 하나의 “원본 문서”를 표현합니다(PDF 1개, URL 1개, Notes 1개).
    # - text는 원문(또는 페이지별 원문)의 모음이고 meta에는 source/url/page 같은 추적 정보를 둡니다.
    # - 이후 chunking 단계에서 meta를 그대로 복사해 [source|p?|c?] 인용을 만들 수 있게 합니다.
    text: str
    meta: Dict[str, Any]


def _clean_text(s: str) -> str:
    # - PDF/웹에서 나온 텍스트는 공백/개행이 지저분한 경우가 많습니다.
    # - 연속 공백/개행을 정리해서 chunk 품질(문장 단절, 불필요한 중복)을 개선합니다.
    # - “완벽한 정제”보다 실습용으로 안정적인 최소 정제를 목표로 합니다.
    s = s.replace("\u00a0", " ")
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n{3,}", "\n\n", s)
    return s.strip()


def load_pdf_documents(file_bytes: bytes, source_name: str) -> List[Document]:
    # - PDF를 “페이지 단위 Document” 리스트로 로드합니다(메타에 page 포함).
    # - PdfReader는 bytes가 아니라 seek 가능한 stream을 요구하므로 BytesIO로 감쌉니다.
    # - 페이지 meta가 있으면 RAG 답변에서 [source|p3|c12]처럼 추적이 정확해집니다.
    stream = io.BytesIO(file_bytes)
    reader = PdfReader(stream)

    docs: List[Document] = []
    for pageno, page in enumerate(reader.pages, start=1):
        t = page.extract_text() or ""
        t = _clean_text(t)
        if t:
            docs.append(Document(text=t, meta={"source": source_name, "page": pageno}))
    return docs


def load_web_document(url: str, timeout: float = 15.0) -> Document:
    # - URL의 HTML을 가져와 텍스트만 추출합니다(간단 버전).
    # - 실무에서는 본문 selector/boilerplate 제거가 중요하지만, 실습은 흐름 이해가 목적입니다.
    # - meta에 url을 넣어 citation에 출처를 남길 수 있게 합니다.
    r = requests.get(url, timeout=timeout, headers={"User-Agent": "Mozilla/5.0"})
    r.raise_for_status()
    soup = BeautifulSoup(r.text, "html.parser")
    text = soup.get_text("\n")
    text = _clean_text(text)
    return Document(text=text, meta={"url": url})


def load_notes_document(notes: str) -> Document:
    # - 사용자가 직접 붙여넣는 메모를 하나의 문서로 취급합니다.
    # - meta.source="notes"로 표시해 PDF/웹과 구분되도록 합니다.
    # - 강의에서는 Notes가 “빠른 데이터 입력 채널” 역할을 합니다.
    return Document(text=_clean_text(notes), meta={"source": "notes"})


def split_text(text: str, chunk_size: int, overlap: int) -> List[str]:
    # - 단순 문자 기반 chunking입니다(토큰 기반보다 쉽고 실습에 적합).
    # - overlap을 두어 경계에서 정보 손실을 줄이고 retrieval 안정성을 높입니다.
    # - 문서/언어에 따라 최적 chunk_size는 다르므로 슬라이더로 실험하게 합니다.
    text = _clean_text(text)
    if not text:
        return []
    step = max(1, chunk_size - overlap)
    out: List[str] = []
    for i in range(0, len(text), step):
        part = text[i: i + chunk_size].strip()
        if part:
            out.append(part)
    return out


def make_chunks(docs: List[Document], chunk_size: int, overlap: int) -> List[Dict[str, Any]]:
    # - Document 리스트를 입력받아 {"text":..., "meta":...} chunk 리스트로 변환합니다.
    # - chunk_id를 전역 증가로 부여해 rerank/citation에서 안정적으로 추적하게 합니다.
    # - meta는 그대로 복사하되 chunk_id만 추가해 “근거 단위”를 식별 가능하게 합니다.
    chunks: List[Dict[str, Any]] = []
    cid = 0
    for d in docs:
        parts = split_text(d.text, chunk_size=chunk_size, overlap=overlap)
        for p in parts:
            chunks.append({"text": p, "meta": {**d.meta, "chunk_id": cid}})
            cid += 1
    return chunks
