# rag_core.py
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Tuple, Dict, Any, Optional
import os
import json

import numpy as np
import faiss
from openai import OpenAI

# -----------------------
# 모델 설정
# -----------------------
# - 임베딩 모델: chunk/text를 벡터로 바꿔 FAISS 검색에 사용합니다.
# - 채팅 모델: query rewrite, rerank, 최종 답변 생성에 사용합니다.
# - 실습 3단계는 Chroma 없이 FAISS(IndexFlatIP)만 유지합니다.
EMBED_MODEL = "text-embedding-3-small"
CHAT_MODEL = "gpt-4-0613"


def get_client() -> OpenAI:
    # - 환경변수 OPENAI_API_KEY를 읽어 OpenAI 클라이언트를 만듭니다.
    # - 키가 없으면 즉시 예외를 내서 실습 중 원인 파악이 쉬워집니다.
    # - 이후 임베딩/리라이트/리랭크/답변 생성에서 같은 client를 공유합니다.
    key = os.getenv("OPENAI_API_KEY") or ""
    if not key:
        raise RuntimeError("OPENAI_API_KEY is not set.")
    return OpenAI(api_key=key)


def embed_texts(client: OpenAI, texts: List[str]) -> np.ndarray:
    # - 텍스트 리스트를 임베딩 API로 벡터화합니다.
    # - IndexFlatIP에서 cosine 유사도처럼 쓰기 위해 L2 정규화를 합니다.
    # - 반환 shape은 [N, d], dtype은 float32로 FAISS와 호환됩니다.
    resp = client.embeddings.create(model=EMBED_MODEL, input=texts)
    vecs = np.array([d.embedding for d in resp.data], dtype=np.float32)
    faiss.normalize_L2(vecs)
    return vecs


@dataclass
class VectorIndex:
    # - index: FAISS 인덱스(내적 기반)로 빠른 top-k 검색을 수행합니다.
    # - chunks: 검색 결과를 원문/메타로 복원하기 위한 {"text","meta"} 리스트입니다.
    # - vectors: 전체 벡터를 저장해 MMR의 “다양성(중복 억제)” 계산에 씁니다.
    index: faiss.Index
    chunks: List[Dict[str, Any]]   # {"text":..., "meta":...}
    vectors: np.ndarray            # normalized vectors [N, d] for MMR


def build_faiss_index(client: OpenAI, chunks: List[Dict[str, Any]]) -> VectorIndex:
    # - chunks의 text를 임베딩하고 FAISS(IndexFlatIP) 인덱스를 생성합니다.
    # - 벡터 정규화가 되어 있어 내적(IP)이 곧 cosine 유사도 역할을 합니다.
    # - 인덱스+chunks+vectors를 묶어 Retrieval 파이프라인에서 재사용합니다.
    texts = [c["text"] for c in chunks]
    vecs = embed_texts(client, texts)
    dim = vecs.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(vecs)
    return VectorIndex(index=index, chunks=chunks, vectors=vecs)


# -----------------------
# 3-1) Query rewrite
# -----------------------
def rewrite_query(client: OpenAI, query: str) -> str:
    # - 사용자 질문을 “검색에 유리한 짧은 질의”로 재작성합니다.
    # - 핵심 엔티티/제약/기술 용어는 유지하고 군더더기는 제거합니다.
    # - 답을 만들지 말고 한 줄만 출력하도록 규칙을 고정합니다.
    prompt = f"""
You rewrite user questions into a SHORT search query for retrieval.
Rules:
- Keep key entities/constraints/technical terms.
- Remove filler. Output ONE line only.
- Do not answer the question.

User question:
{query}

Search query:
""".strip()

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.0,
        max_tokens=64,
    )
    out = r.choices[0].message.content.strip()
    return out if out else query


# -----------------------
# 3-2) MMR selection
# -----------------------
def _mmr_select(
    qvec: np.ndarray,            # [d] normalized
    cand_ids: List[int],
    vectors: np.ndarray,         # [N, d] normalized
    k: int,
    lambda_mult: float = 0.5
) -> List[int]:
    # - MMR은 “관련성”과 “다양성”을 함께 고려해 후보를 고릅니다.
    # - q에 가까우면서도 이미 뽑힌 chunk와 너무 비슷하면 패널티를 줍니다.
    # - lambda_mult↑: 관련성 우선, lambda_mult↓: 다양성(중복 억제) 우선입니다.
    selected: List[int] = []
    remaining = cand_ids.copy()

    q_sims = {i: float(np.dot(qvec, vectors[i])) for i in remaining}

    while remaining and len(selected) < k:
        best_id = None
        best_val = -1e9

        for cid in remaining:
            rel = q_sims[cid]
            if not selected:
                div = 0.0
            else:
                div = max(float(np.dot(vectors[cid], vectors[sid])) for sid in selected)

            mmr = lambda_mult * rel - (1.0 - lambda_mult) * div
            if mmr > best_val:
                best_val = mmr
                best_id = cid

        selected.append(best_id)
        remaining.remove(best_id)

    return selected


# -----------------------
# 3-3) LLM rerank
# -----------------------
def rerank_llm(
    client: OpenAI,
    query: str,
    candidates: List[Dict[str, Any]],
    top_k: int
) -> List[int]:
    # - 후보 chunk들을 “질문에 직접 답하는 정도” 기준으로 다시 정렬합니다.
    # - 모델은 순서만 JSON({"ranked":[...]})으로 반환하고, 내용 생성은 하지 않습니다.
    # - 출력이 깨져도 앱이 죽지 않도록 인덱스 리스트를 정규화(permutation)합니다.
    items = []
    for i, c in enumerate(candidates):
        meta = c.get("meta", {})
        src = meta.get("source") or meta.get("url") or "unknown"
        page = meta.get("page", "")
        cid = meta.get("chunk_id", "")
        items.append({
            "i": i,
            "source": src,
            "page": page,
            "chunk_id": cid,
            "text": (c.get("text", "")[:1200]),
        })

    prompt = f"""
You are a reranker. Rank candidates by how directly they answer the question.
Return JSON only: {{"ranked":[0,1,2,...]}}.

Question:
{query}

Candidates (JSON):
{json.dumps(items, ensure_ascii=False)}
""".strip()

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.0,
        max_tokens=256,
    )
    out = r.choices[0].message.content.strip()

    def _normalize(order: List[int], n: int) -> List[int]:
        # - 0..n-1 범위 밖/중복 인덱스를 제거해 안전한 순열을 만듭니다.
        # - 빠진 항목은 원래 순서대로 뒤에 채워 항상 길이 n을 보장합니다.
        # - 이렇게 하면 rerank 결과가 깨져도 IndexError 없이 동작합니다.
        seen = set()
        cleaned: List[int] = []
        for x in order:
            if isinstance(x, int) and 0 <= x < n and x not in seen:
                cleaned.append(x)
                seen.add(x)
        for i in range(n):
            if i not in seen:
                cleaned.append(i)
        return cleaned

    try:
        ranked = json.loads(out).get("ranked", [])
        ranked = _normalize(ranked, len(candidates))
        return ranked[: min(top_k, len(candidates))]
    except Exception:
        return list(range(min(top_k, len(candidates))))


def _format_citation(meta: Dict[str, Any]) -> str:
    # - 답변과 evidence 출력에서 통일된 citation 문자열을 만듭니다.
    # - meta의 source/url, page, chunk_id를 조합해 추적 가능하게 합니다.
    # - 예: [file.pdf|p3|c12], [https://...|p0|c5]
    src = meta.get("source") or meta.get("url") or "unknown"
    page = meta.get("page")
    cid = meta.get("chunk_id")

    parts = [str(src)]
    if page is not None and page != "":
        parts.append(f"p{page}")
    if cid is not None and cid != "":
        parts.append(f"c{cid}")
    return "[" + "|".join(parts) + "]"


# -----------------------
# 3-4) Retrieval: rewrite -> fetch_k -> MMR -> rerank
# -----------------------
def retrieve(
    client: OpenAI,
    vindex: VectorIndex,
    query: str,
    top_k: int = 4,
    fetch_k: Optional[int] = None,
    use_rewrite: bool = True,
    use_mmr: bool = True,
    mmr_lambda: float = 0.5,
    use_rerank: bool = True,
) -> Tuple[str, List[Tuple[Dict[str, Any], float]]]:
    # - 3단계 Retrieval 파이프라인을 한 함수로 묶은 “메인 엔진”입니다.
    # - rewrite로 검색 질의를 만든 뒤, FAISS에서 fetch_k개 후보를 확보합니다.
    # - MMR로 top_k를 뽑고, rerank로 “직접 답 근거”가 앞에 오도록 재정렬합니다.
    search_query = rewrite_query(client, query) if use_rewrite else query
    fk = fetch_k if fetch_k is not None else max(top_k * 4, 20)

    qv = embed_texts(client, [search_query])  # [1, d] normalized
    scores, ids = vindex.index.search(qv, fk)

    cand_ids = [int(i) for i in ids[0] if i != -1]

    # 1) pick via MMR (or plain top-k)
    if use_mmr and len(cand_ids) > top_k:
        picked_ids = _mmr_select(
            qvec=qv[0],
            cand_ids=cand_ids,
            vectors=vindex.vectors,
            k=top_k,
            lambda_mult=mmr_lambda,
        )
    else:
        picked_ids = cand_ids[:top_k]

    # - picked는 (chunk, score) 리스트이며 score는 cosine 유사도(정규화 내적)입니다.
    picked = [(vindex.chunks[i], float(np.dot(qv[0], vindex.vectors[i]))) for i in picked_ids]

    # 2) rerank (by LLM)
    if use_rerank and len(picked) > 1:
        cand_chunks = [c for (c, _) in picked]
        order = rerank_llm(client, query, cand_chunks, top_k=len(cand_chunks))
        picked = [picked[i] for i in order]

    return search_query, picked


def answer_with_rag(
    client: OpenAI,
    query: str,
    retrieved: List[Tuple[Dict[str, Any], float]]
) -> str:
    # - retrieval 결과를 Evidence 블록으로 구성해 “근거 기반 답변”을 강제합니다.
    # - 근거가 부족하면 부족한 점을 말하고 clarifying question 1개만 하도록 합니다.
    # - 최종 답변에 [source|p?|c?] 인용을 반드시 포함하도록 프롬프트로 고정합니다.
    blocks = []
    for i, (ch, score) in enumerate(retrieved, start=1):
        cite = _format_citation(ch.get("meta", {}))
        blocks.append(f"[{i}] {cite} (score={score:.3f})\n{ch.get('text','')}")
    evidence = "\n\n".join(blocks)

    prompt = f"""
You are a RAG assistant. Use ONLY the provided evidence.
If evidence is insufficient, say what is missing and ask one clarifying question.
You MUST cite sources in the final answer using the citation format like [source|p3|c12].

Question:
{query}

Evidence:
{evidence}

Write:
1) Evidence summary (3-6 bullets)
2) Final answer (concise, with citations)
""".strip()

    r = client.chat.completions.create(
        model=CHAT_MODEL,
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2,
        max_tokens=600,
    )
    return r.choices[0].message.content.strip()
