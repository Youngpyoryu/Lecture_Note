# app.py
from __future__ import annotations

import os
from typing import List, Dict, Any, Tuple

import streamlit as st

from loaders import (
    Document,
    load_pdf_documents,
    load_web_document,
    load_notes_document,
    make_chunks,
)

from chroma_core import (
    get_client,
    get_store,
    upsert_chunks,
    retrieve,
    answer_with_rag,
)

# -----------------------
# UI helpers
# -----------------------
def _ensure_client_from_ui_key() -> None:
    # - 사이드바에서 받은 API Key를 환경변수에 반영합니다.
    # - chroma_core.get_client()는 환경변수에서 키를 읽으므로 동기화가 필요합니다.
    # - 키가 비어 있으면 build/ask 시점에 에러가 나 원인 파악이 쉬워집니다.
    key = st.session_state.get("OPENAI_API_KEY", "").strip()
    if key:
        os.environ["OPENAI_API_KEY"] = key


def _index_identity_box(info: Dict[str, Any] | None) -> None:
    # - 현재 인덱스(컬렉션)가 “무엇으로, 어떤 파라미터로” 만들어졌는지 보여줍니다.
    # - pages/chunks/chunk_size/overlap/db를 한 줄로 노출해 재현성을 확보합니다.
    # - 인덱스가 없으면 없다고 표시해 사용자 흐름(먼저 빌드)을 명확히 합니다.
    if not info:
        st.info("현재 인덱스: (없음)\n\n인덱스를 먼저 생성하세요.")
        return

    src_line = info.get("source_line", "unknown")
    pages = info.get("pages", "?")
    chunks = info.get("chunks", "?")
    chunk_size = info.get("chunk_size", "?")
    overlap = info.get("overlap", "?")
    db = info.get("db", "chroma_db/?")

    st.info(
        f"현재 인덱스: {src_line}\n\n"
        f"pages={pages}|chunks={chunks}|chunk_size={chunk_size}|overlap={overlap}\n"
        f"db={db}"
    )


def _format_hit_title(i: int, meta: Dict[str, Any], score: float) -> str:
    # - Evidence expander 제목을 [i] source p? c? | score=? 로 통일합니다.
    # - PDF는 source/page, 웹은 url, 노트는 source=notes로 추적 가능합니다.
    # - “검증 가능한 RAG”의 핵심인 meta 노출을 UI에서 유지합니다.
    src = meta.get("source") or meta.get("url") or "unknown"
    page = meta.get("page")
    cid = meta.get("chunk_id")

    parts = [str(src)]
    if page not in (None, ""):
        parts.append(f"p{page}")
    if cid not in (None, ""):
        parts.append(f"c{cid}")

    return f"[{i}] " + " ".join(parts) + f" | score={score:.3f}"


def _meta_block(meta: Dict[str, Any]) -> str:
    # - Chunk 미리보기/증거 확인에서 meta를 읽기 쉽게 출력합니다.
    # - source/url/page/chunk_id를 우선 노출해 디버깅과 검증에 도움을 줍니다.
    # - 강의에서는 “근거 추적 정보가 답변 품질의 절반”임을 체감시키는 장치입니다.
    keys = ["source", "url", "page", "chunk_id"]
    lines = ["{"]
    wrote = False
    for k in keys:
        v = meta.get(k)
        if v not in (None, ""):
            lines.append(f'  "{k}" : "{v}"')
            wrote = True
    if not wrote:
        lines.append('  "info" : "no meta"')
    lines.append("}")
    return "\n".join(lines)


# -----------------------
# Streamlit App (2단계 UI 형태 유지 + Chroma 저장/검색 + 3단계 옵션)
# -----------------------
# - 좌측: Key/문서입력/청킹/인덱싱 + (추가) Retrieval 고급옵션
# - 중앙: 인덱스 정체성 박스 + 질문 입력 + 검색/응답
# - 우측: chunk 미리보기
# - 하단: Retrieved Evidence + Answer
st.set_page_config(page_title="RAG Chatbot (PDF / Web / Notes)", layout="wide")
st.title("RAG Chatbot (PDF / Web / Notes)")

# 세션 상태
if "OPENAI_API_KEY" not in st.session_state:
    st.session_state.OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
if "client" not in st.session_state:
    st.session_state.client = None
if "store" not in st.session_state:
    st.session_state.store = None
if "chunks" not in st.session_state:
    st.session_state.chunks = []
if "index_info" not in st.session_state:
    st.session_state.index_info = None

# 질의/결과 세션(버튼 클릭 후 화면 유지용)
if "last_search_query" not in st.session_state:
    st.session_state.last_search_query = ""
if "last_hits" not in st.session_state:
    st.session_state.last_hits = []  # List[Tuple[chunk, score]]

# -----------------------
# Sidebar
# -----------------------
with st.sidebar:
    st.header("0) OpenAI API Key")
    st.text_input("OPENAI_API_KEY", key="OPENAI_API_KEY", type="password")
    _ensure_client_from_ui_key()

    st.divider()
    st.header("1) 문서 입력")
    source_kind = st.radio("소스 선택", ["PDF 업로드", "웹 URL", "노트 입력"], index=0)

    pdf_file = None
    url = ""
    notes = ""

    if source_kind == "PDF 업로드":
        pdf_file = st.file_uploader("PDF 파일", type=["pdf"])
    elif source_kind == "웹 URL":
        url = st.text_input("웹 URL", value="")
    else:
        notes = st.text_area("노트 입력", height=160)

    st.divider()
    st.header("2) 청킹/인덱싱")
    chunk_size = st.slider("chunk_size", 300, 1500, 800, 50)
    overlap = st.slider("overlap", 0, 400, 120, 10)

    # Chroma 저장 경로/컬렉션(강의에서 “DB처럼 관리”를 보여주기 위해 노출)
    persist_path = st.text_input("Chroma persist_path", value="./chroma_db")
    collection_name = st.text_input("Chroma collection", value="rag_chunks")

    build_btn = st.button("인덱스 생성", use_container_width=True)

    st.divider()
    st.header("3) Retrieval 고급 옵션")
    use_rewrite = st.checkbox("Query rewrite", value=True)
    fetch_k = st.slider("fetch_k(후보 수)", 8, 80, 20, 4)
    use_mmr = st.checkbox("MMR (중복 감소)", value=True)
    mmr_lambda = st.slider("MMR lambda(관련성↔다양성)", 0.0, 1.0, 0.5, 0.05)
    use_rerank = st.checkbox("LLM Re-rank", value=True)

# -----------------------
# Build Index (Chroma upsert)
# -----------------------
# - 문서를 로드해 pages(Document) -> chunks(meta 포함)로 변환합니다.
# - chunks를 임베딩해 Chroma 컬렉션에 upsert(저장)합니다.
# - index_info에 DB 경로/컬렉션을 기록해 재현성을 확보합니다.
if build_btn:
    _ensure_client_from_ui_key()
    try:
        st.session_state.client = get_client()
    except Exception as e:
        st.session_state.client = None
        st.error(f"API Key 설정이 필요합니다: {e}")

    if st.session_state.client is not None:
        docs: List[Document] = []
        src_line = "unknown"
        pages = 0

        if source_kind == "PDF 업로드":
            if pdf_file is None:
                st.warning("PDF를 업로드하세요.")
            else:
                docs = load_pdf_documents(pdf_file.getvalue(), source_name=pdf_file.name)
                src_line = pdf_file.name
                pages = len(docs)

        elif source_kind == "웹 URL":
            if not url.strip():
                st.warning("URL을 입력하세요.")
            else:
                try:
                    docs = [load_web_document(url.strip())]
                    src_line = url.strip()
                    pages = 1
                except Exception as e:
                    st.error(f"URL 로딩 실패: {e}")

        else:  # 노트 입력
            if not notes.strip():
                st.warning("노트를 입력하세요.")
            else:
                docs = [load_notes_document(notes.strip())]
                src_line = "notes"
                pages = 1

        if docs:
            chunks = make_chunks(docs, chunk_size=chunk_size, overlap=overlap)
            st.session_state.chunks = chunks

            # Chroma store 생성 + 저장(upsert)
            st.session_state.store = get_store(persist_path=persist_path, name=collection_name)
            upsert_chunks(st.session_state.client, st.session_state.store, chunks)

            st.session_state.index_info = {
                "source_line": src_line,
                "pages": pages,
                "chunks": len(chunks),
                "chunk_size": chunk_size,
                "overlap": overlap,
                "db": f"{persist_path}/{collection_name}",
            }

            st.session_state.last_search_query = ""
            st.session_state.last_hits = []
            st.success("인덱스 생성 완료 (Chroma에 저장됨)")

# -----------------------
# Main layout
# -----------------------
col_left, col_right = st.columns([2, 1], gap="large")

with col_left:
    st.header("3) 질문")
    _index_identity_box(st.session_state.index_info)

    q = st.text_input("질문을 입력하세요", value="예: HNSW가 벡터 검색에서 하는 역할은?")
    top_k = st.slider("top_k", 1, 8, 4, 1)

    ask_btn = st.button("검색+응답")

    if ask_btn:
        if st.session_state.store is None:
            st.warning("먼저 인덱스를 생성하세요.")
        else:
            search_query, hits = retrieve(
                st.session_state.client,
                st.session_state.store,
                q,
                top_k=top_k,
                fetch_k=fetch_k,
                use_rewrite=use_rewrite,
                use_mmr=use_mmr,
                mmr_lambda=mmr_lambda,
                use_rerank=use_rerank,
                where=None,
            )
            st.session_state.last_search_query = search_query
            st.session_state.last_hits = hits

    if st.session_state.last_search_query:
        st.caption(f"검색용 질의(rewrite): {st.session_state.last_search_query}")

with col_right:
    st.header("Chunk 미리보기")

    chunks = st.session_state.chunks
    n = len(chunks)
    st.write(f"총 {n} chunks")

    if n == 0:
        st.info("인덱스를 생성하면 chunk 미리보기가 활성화됩니다.")
    else:
        cid = st.slider("미리볼 chunk_id", 0, n - 1, 0, 1)
        ch = chunks[cid]
        meta = ch.get("meta", {})
        st.code(_meta_block(meta), language="json")
        st.write(ch.get("text", ""))

# -----------------------
# Retrieved Evidence + Answer
# -----------------------
st.subheader("Retrieved Evidence")

hits = st.session_state.last_hits
if not hits:
    st.info("검색 결과가 여기에 표시됩니다.")
else:
    for i, (ch, score) in enumerate(hits, start=1):
        meta = ch.get("meta", {})
        title = _format_hit_title(i, meta, score)
        with st.expander(title, expanded=(i == 1)):
            st.code(_meta_block(meta), language="json")
            st.write(ch.get("text", ""))

    st.subheader("Answer")
    ans = answer_with_rag(st.session_state.client, q, hits)
    st.write(ans)
